import { jsPDF } from "jspdf";
import { isLeadMagnet } from "./templates";
import type { BidPackage, CompanyProfile } from "./types";
import { formatDate } from "./utils";
import { downloadBlob, fileStem } from "./files";

const NAVY: [number, number, number] = [27, 42, 74];
const STEEL: [number, number, number] = [47, 74, 109];
const STRIPE: [number, number, number] = [61, 79, 70];
const INK: [number, number, number] = [28, 25, 22];
const MUTED: [number, number, number] = [107, 100, 88];
const LINE: [number, number, number] = [212, 205, 192];
const PAPER: [number, number, number] = [247, 244, 238];
const BAND: [number, number, number] = [231, 226, 214];

const MARGIN = 48;
const PAGE_W = 612;
const PAGE_H = 792;
const CONTENT_W = PAGE_W - MARGIN * 2;
const FOOTER_TOP = PAGE_H - 36;
const H2_H = 18;
const H2_AFTER = 8;
const SECTION_GAP = 10;
const BULLET_GAP = 4;
const LINE_H = 13;

function baseline(top: number, size: number) {
  return top + size * 0.9;
}

function gcName(c: CompanyProfile) {
  return c.legalName || c.name || "General Contractor";
}

function filled(items: string[]) {
  return items.map((s) => s.trim()).filter(Boolean);
}

export function buildPackagePdf(pack: BidPackage, company: CompanyProfile) {
  const doc = new jsPDF({ unit: "pt", format: "letter", orientation: "portrait" });
  const gc = gcName(company);
  const inv = pack.invitation;
  const ctx: Ctx = { doc, pack, company, gc, inv, page: 1, y: 0, leadMagnet: isLeadMagnet(company) };

  pageInvite(ctx);
  pageProject(ctx);
  pageScope(ctx);
  pageBidForm(ctx);
  pageInsurance(ctx);
  pageSchedule(ctx);
  pageDrawings(ctx);
  return doc;
}

export async function downloadPackagePdf(pack: BidPackage, company: CompanyProfile) {
  const doc = buildPackagePdf(pack, company);
  downloadBlob(doc.output("blob"), `${fileStem(pack)}.pdf`);
}

type Ctx = {
  doc: jsPDF;
  pack: BidPackage;
  company: CompanyProfile;
  gc: string;
  inv: BidPackage["invitation"];
  page: number;
  y: number;
  leadMagnet: boolean;
};

function startPage(ctx: Ctx, title: string) {
  const { doc, gc, inv, page, leadMagnet } = ctx;
  if (page > 1) doc.addPage();
  doc.setFillColor(...PAPER);
  doc.rect(0, 0, PAGE_W, PAGE_H, "F");

  doc.setFillColor(...NAVY);
  doc.rect(0, 0, PAGE_W, 56, "F");
  doc.setTextColor(247, 244, 238);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(gc.toUpperCase(), MARGIN, 24);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(leadMagnet ? "BID INVITATION" : "SUBCONTRACTOR BID PACKAGE", PAGE_W - MARGIN, 20, {
    align: "right",
  });
  doc.text(inv.projectNo || "Project no. pending", PAGE_W - MARGIN, 34, { align: "right" });
  doc.setFillColor(...STRIPE);
  doc.rect(0, 56, PAGE_W, 4, "F");

  doc.setTextColor(...MUTED);
  doc.setFontSize(8);
  doc.text(title, MARGIN, 80);
  doc.text(`Page ${page}`, PAGE_W - MARGIN, 80, { align: "right" });

  doc.setFillColor(...BAND);
  doc.rect(0, PAGE_H - 32, PAGE_W, 32, "F");
  doc.setDrawColor(...LINE);
  doc.setLineWidth(0.4);
  doc.line(0, PAGE_H - 32, PAGE_W, PAGE_H - 32);
  doc.setTextColor(...MUTED);
  doc.setFontSize(7);
  doc.text(
    leadMagnet
      ? "Issued by Lead Magnet  ·  Working invitation — official IFB governs  ·  Quantities estimated"
      : "Issued for bidding  ·  Quantities are estimated  ·  Field-measure before pour / install",
    PAGE_W / 2,
    PAGE_H - 14,
    { align: "center" },
  );

  ctx.y = 92;
  ctx.page += 1;
}

function h2(ctx: Ctx, label: string) {
  const { doc } = ctx;
  need(ctx, H2_H + H2_AFTER + 24);
  doc.setFillColor(...STEEL);
  doc.rect(MARGIN, ctx.y, CONTENT_W, H2_H, "F");
  doc.setTextColor(247, 244, 238);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text(label.toUpperCase(), MARGIN + 8, ctx.y + 12);
  ctx.y += H2_H + H2_AFTER;
}

function para(ctx: Ctx, text: string, size = 10) {
  const { doc } = ctx;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(size);
  doc.setTextColor(...INK);
  const lines = doc.splitTextToSize(text || "—", CONTENT_W) as string[];
  need(ctx, lines.length * LINE_H + 8);
  const top = ctx.y;
  lines.forEach((line, i) => {
    doc.text(line, MARGIN, baseline(top + i * LINE_H, size));
  });
  ctx.y = top + lines.length * LINE_H + 6;
}

function bullets(ctx: Ctx, items: string[]) {
  const rows = filled(items);
  if (!rows.length) {
    para(ctx, "To be issued.");
    return;
  }
  const { doc } = ctx;
  const size = 10;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(size);
  doc.setTextColor(...INK);
  const textW = CONTENT_W - 22;
  for (const item of rows) {
    const lines = doc.splitTextToSize(item, textW) as string[];
    const blockH = lines.length * LINE_H + BULLET_GAP;
    need(ctx, blockH + 4);
    const top = ctx.y;
    const firstBase = baseline(top, size);
    doc.setFillColor(...STRIPE);
    doc.circle(MARGIN + 4, firstBase - 3, 1.7, "F");
    lines.forEach((line, i) => {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(size);
      doc.setTextColor(...INK);
      doc.text(line, MARGIN + 16, baseline(top + i * LINE_H, size));
    });
    ctx.y = top + blockH;
  }
  ctx.y += SECTION_GAP;
}

function table(ctx: Ctx, headers: string[], rows: string[][]) {
  const { doc } = ctx;
  const cols = headers.length;
  const widths = headers.map((_, i) => {
    if (cols === 2) return i === 0 ? 148 : CONTENT_W - 148;
    if (cols === 3) return [168, 196, CONTENT_W - 364][i];
    if (cols === 5) return [214, 54, 50, 92, CONTENT_W - 410][i];
    if (cols === 4) return [CONTENT_W * 0.44, CONTENT_W * 0.14, CONTENT_W * 0.21, CONTENT_W * 0.21][i];
    return CONTENT_W / cols;
  });
  const headerH = 16;
  const cellLine = 11;

  const drawHeader = () => {
    doc.setFillColor(...NAVY);
    doc.rect(MARGIN, ctx.y, CONTENT_W, headerH, "F");
    doc.setTextColor(247, 244, 238);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    let x = MARGIN + 8;
    headers.forEach((h, i) => {
      doc.text(h.toUpperCase(), x, ctx.y + 11);
      x += widths[i];
    });
    ctx.y += headerH;
  };

  need(ctx, headerH + 28);
  drawHeader();

  rows.forEach((row, ri) => {
    const wrapped = row.map((cell, i) =>
      doc.splitTextToSize(cell || "—", widths[i] - 14) as string[],
    );
    const rowH = Math.max(18, Math.max(...wrapped.map((w) => w.length)) * cellLine + 8);
    if (ctx.y + rowH > FOOTER_TOP) {
      startPage(ctx, "continued");
      drawHeader();
    }
    if (ri % 2 === 0) {
      doc.setFillColor(...BAND);
      doc.rect(MARGIN, ctx.y, CONTENT_W, rowH, "F");
    }
    doc.setDrawColor(...LINE);
    doc.setLineWidth(0.35);
    doc.line(MARGIN, ctx.y + rowH, MARGIN + CONTENT_W, ctx.y + rowH);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...INK);
    let x = MARGIN + 8;
    wrapped.forEach((lines, i) => {
      lines.forEach((ln, li) => {
        doc.text(ln, x, ctx.y + 12 + li * cellLine);
      });
      x += widths[i];
    });
    ctx.y += rowH;
  });
  ctx.y += SECTION_GAP;
}

function need(ctx: Ctx, h: number) {
  if (ctx.y + h > FOOTER_TOP) startPage(ctx, "continued");
}

function pageInvite(ctx: Ctx) {
  const { doc, inv, pack, gc, leadMagnet } = ctx;
  startPage(ctx, "01  —  Invitation to Bid");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(...NAVY);
  doc.text("Invitation to Bid", MARGIN, baseline(ctx.y, 20));
  ctx.y += 22;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...MUTED);
  doc.text(`Trade: ${pack.trade}   ·   Bid package no. ${inv.packageNo || "—"}`, MARGIN, baseline(ctx.y, 10));
  ctx.y += 16;

  if (leadMagnet) {
    para(
      ctx,
      "This invitation is issued by Lead Magnet. It is a working package to help you price the job. It is not the official IFB. Official bids go to the contracting officer on the contacts page. Questions on this package: 855-799-8420.",
    );
  }

  table(ctx, ["Field", "Value"], [
    ["Project", inv.projectName],
    ["Site ID", inv.siteId],
    ["Address", inv.address],
    ["Owner", `${inv.owner}${inv.occupied ? "  (occupied)" : ""}`],
    [leadMagnet ? "Issued by" : "General contractor", gc],
    [leadMagnet ? "Solicitation no." : "GC project no.", inv.projectNo],
  ]);

  h2(ctx, "Bid milestones");
  table(ctx, ["Item", "Date / time", "Notes"], [
    ["Documents issued", formatDate(inv.documentsIssued), "This package"],
    ["RFIs due", formatDate(inv.rfiDue), "Email only"],
    ["Bids due", `${formatDate(inv.bidDue)}  ${inv.bidDueTime}`.trim(), "Late bids not opened"],
    ["Apparent low notified", formatDate(inv.awardNotify), "Subject to vetting"],
    ["Work window", inv.workWindow, ""],
  ]);

  h2(ctx, "How to submit");
  para(
    ctx,
    `Email one PDF to ${inv.submitTo || "—"} with subject: ${inv.projectNo || "PROJECT"} / ${inv.packageNo || "PKG"} / [Your Company].`,
  );
  para(ctx, inv.submitNotes);
}

function pageProject(ctx: Ctx) {
  const { pack, inv } = ctx;
  startPage(ctx, "02  —  Project Data & Contacts");
  h2(ctx, "Project data");
  table(ctx, ["Field", "Value"], [
    ["Store / site ID", inv.siteId],
    ["Building status", pack.project.buildingStatus],
    ["Work area", pack.project.workArea],
    ["Existing conditions", pack.project.existingConditions],
    ["Access", pack.project.access],
    ["Dumpster / washout", pack.project.dumpster],
    ["Permits", pack.project.permits],
    ["Prevailing wage", pack.project.prevailingWage],
    ["Tax", pack.project.tax],
  ]);
  h2(ctx, "Contacts");
  table(
    ctx,
    ["Role", "Name", "Email / phone"],
    pack.contacts.map((c) => [c.role, c.name, [c.email, c.phone].filter(Boolean).join("  ·  ")]),
  );
  h2(ctx, "Documents in this package");
  bullets(ctx, pack.documentsList);
}

function pageScope(ctx: Ctx) {
  const { pack, inv } = ctx;
  startPage(ctx, "03  —  Scope of Work");
  h2(ctx, `Base bid — package ${inv.packageNo || "—"}`);
  bullets(ctx, pack.scope.baseItems);
  h2(ctx, "Included");
  bullets(ctx, pack.scope.included);
  h2(ctx, "Excluded");
  bullets(ctx, pack.scope.excluded);
  h2(ctx, "Unit prices — used for adds / deducts");
  bullets(ctx, pack.scope.unitPriceNotes);
}

function pageBidForm(ctx: Ctx) {
  const { pack, inv } = ctx;
  startPage(ctx, "04  —  Bid Form (required)");
  const { doc } = ctx;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(...NAVY);
  doc.text(`Bid Form — Package ${inv.packageNo || "—"}`, MARGIN, baseline(ctx.y, 16));
  ctx.y += 20;
  para(ctx, "Complete every line. Incomplete forms are not evaluated.");
  para(ctx, "Subcontractor legal name: ________________________________");
  para(ctx, "License no. / classification: ______________________________");
  para(ctx, "Contact / cell / email: ____________________________________");
  h2(ctx, "Price breakout (USD)");
  table(ctx, ["Item", "Qty", "Unit", "Unit price", "Amount"], [
    ...pack.bidForm.lines.map((l) => [l.description, l.qty, l.unit, "$ ________", "$ ________"]),
    ["BASE BID (sum of lines above)", "", "", "", "$ ________"],
    ["Sales tax (if applicable)", "", "", "", "$ ________"],
    ["TOTAL BID", "", "", "", "$ ________"],
  ]);
  h2(ctx, "Unit prices for changes");
  table(
    ctx,
    ["Description", "Unit", "Add", "Deduct"],
    pack.bidForm.changePrices.map((l) => [l.description, l.unit, "$ ________", "$ ________"]),
  );
  h2(ctx, "Acknowledgements — initial");
  bullets(
    ctx,
    pack.bidForm.acknowledgements.filter(Boolean).map((a) => `____  ${a}`),
  );
  para(ctx, "Authorized signature: _______________________________     Date: ______________");
}

function pageInsurance(ctx: Ctx) {
  const { pack, gc } = ctx;
  startPage(ctx, "05  —  Insurance, Bond & Safety");
  h2(ctx, "Certificate of insurance — minimums");
  table(
    ctx,
    ["Coverage", "Minimum limit", "Notes"],
    pack.insurance.coverages.map((c) => [c.coverage, c.limit, c.notes]),
  );
  para(ctx, `Additional insureds: ${pack.insurance.additionalInsured || "—"}`);
  para(ctx, `Certificate holder: ${pack.insurance.certificateHolder || gc}`);
  h2(
    ctx,
    `Bond (threshold $${Number(pack.insurance.bondThreshold || 0).toLocaleString()})`,
  );
  bullets(ctx, pack.insurance.bondNotes);
  h2(ctx, "Safety / site rules that affect price");
  bullets(ctx, pack.insurance.safety);
}

function pageSchedule(ctx: Ctx) {
  const { pack } = ctx;
  startPage(ctx, "06  —  Work Restrictions / Schedule");
  h2(ctx, "Hours");
  bullets(ctx, pack.schedule.hours);
  h2(ctx, "Operations");
  bullets(ctx, pack.schedule.operations);
  h2(ctx, "Phasing");
  table(
    ctx,
    ["Phase", "Nights (est.)", "Work"],
    pack.schedule.phases.map((ph) => [ph.name, ph.nights, ph.work]),
  );
  h2(ctx, "What bidders may ask before bidding");
  bullets(ctx, pack.schedule.bidderQuestions);
  if (pack.schedule.liquidatedDamages) {
    para(ctx, `Liquidated damages: ${pack.schedule.liquidatedDamages}`);
  }
}

function pageDrawings(ctx: Ctx) {
  const { pack } = ctx;
  startPage(ctx, "07  —  Drawings, Specs & Addenda");
  h2(ctx, "Drawing / sketch notes");
  para(ctx, pack.drawings.notes || "Issue a sketch or plan with this package.");
  if (pack.drawings.missing) para(ctx, `Not attached: ${pack.drawings.missing}`);
  h2(ctx, "Specifications");
  const specs = pack.specs.filter((s) => s.title || s.detail);
  if (specs.length) {
    table(
      ctx,
      ["Item", "Requirement"],
      specs.map((s) => [s.title, s.detail]),
    );
  } else {
    para(ctx, "Add product and quality rules.");
  }
  h2(ctx, "Addenda");
  if (pack.addenda.length) {
    table(
      ctx,
      ["No.", "Date", "Summary"],
      pack.addenda.map((a) => [a.number, formatDate(a.date), a.summary]),
    );
  } else {
    para(ctx, "None issued. Record later changes here so bidders price the latest version.");
  }
}
