import { create } from "zustand";
import type { BidPackage, CompanyProfile } from "./types";
import { atterburyPackage, ATTERBURY_ID, samplePackage, SAMPLE_ID } from "./templates";

const KEY = "packet.binder.v1";

type State = {
  hydrated: boolean;
  company: CompanyProfile;
  packages: BidPackage[];
  setHydrated: () => void;
  setCompany: (c: CompanyProfile) => void;
  upsert: (p: BidPackage) => void;
  remove: (id: string) => void;
  duplicate: (id: string) => BidPackage | null;
  loadSample: () => void;
  hydrateFromStorage: () => void;
  ensureSeed: (id: string) => void;
};

function persistSlice(s: State) {
  try {
    localStorage.setItem(
      KEY,
      JSON.stringify({ company: s.company, packages: s.packages }),
    );
  } catch {
    /* ignore quota */
  }
}

export const useBinder = create<State>()((set, get) => ({
  hydrated: false,
  company: {
    name: "Redrock Field Services",
    legalName: "Redrock Field Services, LLC",
    address: "410 W 300 S, Ste 220",
    city: "Salt Lake City",
    state: "UT",
    zip: "84101",
    phone: "801-555-0144",
    email: "druiz@redrockfield.example",
    bidsEmail: "bids@redrockfield.example",
    website: "",
  },
  packages: [atterburyPackage(), samplePackage()],
  setHydrated: () => set({ hydrated: true }),
  setCompany: (company) => {
    set({ company });
    persistSlice(get());
  },
  upsert: (p) => {
    const rest = get().packages.filter((x) => x.id !== p.id);
    set({
      packages: [{ ...p, updatedAt: new Date().toISOString() }, ...rest],
    });
    persistSlice(get());
  },
  remove: (id) => {
    set({ packages: get().packages.filter((p) => p.id !== id) });
    persistSlice(get());
  },
  duplicate: (id) => {
    const src = get().packages.find((p) => p.id === id);
    if (!src) return null;
    const copy: BidPackage = {
      ...structuredClone(src),
      id: crypto.randomUUID(),
      status: "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      invitation: {
        ...src.invitation,
        projectName: src.invitation.projectName
          ? `${src.invitation.projectName} (copy)`
          : "Untitled copy",
        projectNo: "",
      },
    };
    set({ packages: [copy, ...get().packages] });
    persistSlice(get());
    return copy;
  },
  loadSample: () => {
    const sample = samplePackage();
    const rest = get().packages.filter((p) => p.id !== sample.id);
    set({ packages: [sample, ...rest], hydrated: true });
    persistSlice(get());
  },
  ensureSeed: (id) => {
    if (get().packages.some((p) => p.id === id)) return;
    if (id === ATTERBURY_ID) {
      set({ packages: [atterburyPackage(), ...get().packages] });
      persistSlice(get());
    }
    if (id === SAMPLE_ID) {
      set({ packages: [samplePackage(), ...get().packages] });
      persistSlice(get());
    }
  },
  hydrateFromStorage: () => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as {
          company?: CompanyProfile;
          packages?: BidPackage[];
        };
        if (Array.isArray(parsed.packages) && parsed.packages.length > 0) {
          const packages = parsed.packages.filter((p) => p.id !== ATTERBURY_ID);
          packages.unshift(atterburyPackage());
          if (!packages.some((p) => p.id === SAMPLE_ID)) {
            packages.push(samplePackage());
          }
          set({
            company: parsed.company ? { ...get().company, ...parsed.company } : get().company,
            packages,
            hydrated: true,
          });
          persistSlice(get());
          return;
        }
      }
    } catch {
      /* bad json */
    }
    set({
      packages: [atterburyPackage(), samplePackage()],
      hydrated: true,
    });
    persistSlice(get());
  },
}));
