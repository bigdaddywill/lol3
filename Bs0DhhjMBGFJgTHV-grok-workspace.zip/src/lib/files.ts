import type { BidPackage, CompanyProfile } from "./types";

export type PacketFile = {
  version: 1;
  kind: "packet-bid-package";
  exportedAt: string;
  company: CompanyProfile;
  pack: BidPackage;
};

export function fileStem(pack: BidPackage) {
  const bits = [
    pack.invitation.projectNo,
    pack.invitation.packageNo,
    pack.invitation.siteId || pack.invitation.projectName,
  ]
    .map((s) => s.trim())
    .filter(Boolean);
  const raw = bits.join("-") || "bid-package";
  return raw.replace(/[^\w.-]+/g, "-").replace(/-+/g, "-").slice(0, 80);
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function downloadJson(pack: BidPackage, company: CompanyProfile) {
  const payload: PacketFile = {
    version: 1,
    kind: "packet-bid-package",
    exportedAt: new Date().toISOString(),
    company,
    pack,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  downloadBlob(blob, `${fileStem(pack)}.json`);
}

export function parsePacketFile(
  text: string,
  fallbackCompany: CompanyProfile,
): PacketFile {
  const data = JSON.parse(text) as PacketFile | BidPackage;
  if (data && typeof data === "object" && "pack" in data && (data as PacketFile).pack?.invitation) {
    const file = data as PacketFile;
    return {
      version: 1,
      kind: "packet-bid-package",
      exportedAt: file.exportedAt || new Date().toISOString(),
      company: file.company || fallbackCompany,
      pack: file.pack,
    };
  }
  if (data && typeof data === "object" && "invitation" in data && "id" in data) {
    return {
      version: 1,
      kind: "packet-bid-package",
      exportedAt: new Date().toISOString(),
      company: fallbackCompany,
      pack: data as BidPackage,
    };
  }
  throw new Error("Not a Packet bid-package file.");
}
