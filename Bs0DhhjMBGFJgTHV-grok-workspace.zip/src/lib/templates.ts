import { uid, todayISO } from "./utils";
import type { BidPackage, CompanyProfile, Trade } from "./types";

export const defaultCompany = (): CompanyProfile => ({
  name: "",
  legalName: "",
  address: "",
  city: "",
  state: "",
  zip: "",
  phone: "",
  email: "",
  bidsEmail: "",
  website: "",
});

function basePackage(trade: Trade, company: CompanyProfile): BidPackage {
  const now = new Date().toISOString();
  const gc = company.legalName || company.name || "[GC company]";
  const bids = company.bidsEmail || company.email || "bids@your-gc.example";
  return {
    id: uid(),
    createdAt: now,
    updatedAt: now,
    status: "draft",
    trade,
    invitation: {
      projectName: "",
      siteId: "",
      address: "",
      owner: "",
      occupied: true,
      packageNo: "03A",
      projectNo: "",
      documentsIssued: todayISO(),
      rfiDue: "",
      bidDue: "",
      bidDueTime: "2:00 PM",
      awardNotify: "",
      workWindow: "",
      submitTo: bids,
      submitNotes:
        "Email one PDF. Include signed bid form, license, current COI, and bondability letter if your total exceeds the threshold on the insurance page. Unit prices are mandatory. A lump-sum-only quote will be marked incomplete. Do not text numbers to the superintendent.",
    },
    project: {
      buildingStatus: "Occupied — work around live operations",
      workArea: "",
      existingConditions: "",
      access: "",
      dumpster: "GC provides dumpster. Sub loads it. Overages on the bid form.",
      permits: "GC holds building permit. Sub pulls trade permits if required.",
      prevailingWage: "No. Private owner.",
      tax: "Show sales tax separately on the bid form.",
    },
    contacts: [
      {
        id: uid(),
        role: "Project manager",
        name: "",
        email: company.email,
        phone: company.phone,
        notes: "",
      },
      {
        id: uid(),
        role: "Superintendent",
        name: "",
        email: "",
        phone: "",
        notes: "",
      },
      {
        id: uid(),
        role: "Estimator / bids",
        name: "Bids desk",
        email: bids,
        phone: "",
        notes: "",
      },
    ],
    documentsList: [
      "01 Invitation to Bid",
      "02 Project Data & Contacts",
      "03 Scope of Work",
      "04 Bid Form (required)",
      "05 Insurance, Bond & Safety Minimums",
      "06 Work Restrictions / Schedule",
      "07 Sketch / drawing notes",
    ],
    scope: { baseItems: [""], included: [""], excluded: [""], unitPriceNotes: [""] },
    drawings: {
      notes: "Field-measure all quantities. Discrepancies over 10% are an RFI, not a guess.",
      missing: "",
    },
    specs: [{ id: uid(), title: "", detail: "" }],
    bidForm: {
      lines: [{ id: uid(), description: "Mobilization / protection", qty: "1", unit: "LS" }],
      changePrices: [
        { id: uid(), description: "Crew standby, owner delay", qty: "", unit: "HR" },
      ],
      acknowledgements: [
        "I received Invitation, Scope, Bid Form, Insurance sheet, Work Restrictions, and drawings.",
        "I can staff the hours on the schedule page.",
        "I can furnish the insurance limits within 5 days of notice of award.",
        "If my bid is over the bond threshold I attach a surety letter of bondability.",
        "This bid is firm for 30 days. No deposit or off-contract payment is requested.",
      ],
    },
    insurance: {
      coverages: [
        {
          id: uid(),
          coverage: "Commercial General Liability",
          limit: "$1,000,000 occ / $2,000,000 agg",
          notes: "Per project aggregate",
        },
        {
          id: uid(),
          coverage: "Auto liability",
          limit: "$1,000,000",
          notes: "Any auto",
        },
        {
          id: uid(),
          coverage: "Workers’ compensation",
          limit: "Statutory",
          notes: "Include waiver of subrogation",
        },
        {
          id: uid(),
          coverage: "Employer’s liability",
          limit: "$1,000,000",
          notes: "",
        },
        {
          id: uid(),
          coverage: "Umbrella / excess",
          limit: "$1,000,000",
          notes: "Required if base bid ≥ bond threshold",
        },
      ],
      additionalInsured: `${gc} and the Owner, primary and non-contributory.`,
      certificateHolder: gc,
      bondThreshold: "75000",
      bondNotes: [
        "Bids at or over the threshold: attach a letter from a surety admitted in the project state.",
        "If awarded over the threshold, a performance and payment bond equal to 100% of the subcontract may be required within 10 days.",
        "Bond premium, if required, is a line-item reimbursable at cost with backup.",
        "“Bonded” means a surety will stand behind the job. It does not mean licensed or insured.",
      ],
      safety: [
        "Hard hats, hi-vis, and eye protection on site.",
        "Report any injury, property strike, or store complaint to the superintendent before the shift ends.",
        "Your EMR and a 1-page safety sheet may be requested before award.",
      ],
    },
    schedule: {
      hours: [""],
      operations: [""],
      phases: [{ id: uid(), name: "A", nights: "", work: "" }],
      bidderQuestions: [
        "May I walk the site after hours if I check in with the night manager?",
        "Who owns dumpster overages?",
      ],
      liquidatedDamages: "",
    },
    addenda: [],
  };
}

const TRADE_FILL: Record<
  Trade,
  (p: BidPackage) => void
> = {
  "Concrete repair": (p) => {
    p.invitation.packageNo = "03A";
    p.invitation.workWindow = "Nights 10:00 PM – 5:00 AM";
    p.project.workArea = "Apron SF, joint LF, and column-base count — fill from takeoff.";
    p.project.existingConditions = "Existing dock / apron slab. Confirm thickness in the field.";
    p.project.access = "Service yard only. No customer-lot staging.";
    p.scope.baseItems = [
      "Mobilize for night work. Furnish labor, equipment, materials, haul-off, and protection.",
      "Sawcut, remove, and replace failed panels as hatched on the drawing. Match existing elevation ±1/8\".",
      "Route and clean existing control/construction joints and install specified joint filler, recessed 1/8\".",
      "Repair spalled column bases: chip to sound concrete, clean steel, bonding slurry, form and place repair mortar to original profile.",
      "Protect doors, levelers, seals, and the building. No dust inside occupied space.",
      "Place, finish, cure, and saw new joints to match existing pattern.",
      "Daily cleanup. Release required docks each morning unless a written shutdown was issued.",
    ];
    p.scope.included = [
      "Night-shift premium, lights, and a spotter when trucks are backing.",
      "Traffic cones and lighted barricades at the work face.",
      "Concrete, rebar, dowels, epoxy gel, joint filler, repair mortar, and bond breaker.",
    ];
    p.scope.excluded = [
      "Dock leveler replacement or pit steel.",
      "Overhead doors, seals, bumpers, or striping.",
      "Underground plumbing beyond drains shown.",
      "Hazardous material abatement — stop and call the superintendent.",
    ];
    p.scope.unitPriceNotes = [
      "Extra / credit panel replacement per SF.",
      "Extra / credit joint filler per LF.",
      "Extra column-base repair each.",
      "Standby hourly rate if the owner holds the area through no fault of the sub.",
    ];
    p.specs = [
      { id: uid(), title: "Concrete mix", detail: "Match existing PSI unless noted. Confirm with superintendent before first pour." },
      { id: uid(), title: "Joint filler", detail: "Two-component polyurea, Shore A 80–90, or equal approved in writing." },
      { id: uid(), title: "Repair mortar", detail: "Polymer-modified, applied to sound substrate with manufacturer bonding slurry." },
      { id: uid(), title: "Finish / cure", detail: "Match adjacent surface. Curing compound compatible with joint filler." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Mobilization / night setup / protection", qty: "1", unit: "LS" },
      { id: uid(), description: "Apron panel remove & replace", qty: "", unit: "SF" },
      { id: uid(), description: "Joint route / clean / fill", qty: "", unit: "LF" },
      { id: uid(), description: "Column-base spall repairs", qty: "", unit: "EA" },
      { id: uid(), description: "Haul-off / dump fees beyond GC box", qty: "1", unit: "LS" },
    ];
    p.bidForm.changePrices = [
      { id: uid(), description: "Additional panel replacement", qty: "", unit: "SF" },
      { id: uid(), description: "Additional joint filler", qty: "", unit: "LF" },
      { id: uid(), description: "Additional column-base repair", qty: "", unit: "EA" },
      { id: uid(), description: "Crew standby after shift start, owner delay", qty: "", unit: "HR" },
    ];
    p.schedule.hours = [
      "Work face opens 10:00 PM. Tools down, yard swept, docks released by 5:00 AM.",
      "No arrival staging in customer parking before 9:30 PM.",
    ];
    p.schedule.operations = [
      "Named docks stay live every night unless a shutdown ticket is issued that afternoon.",
      "One spotter from the sub crew is required whenever a mixer or saw is in the drive lane.",
      "No radios pointed at the building. No idling under the canopy after 10:30 PM.",
    ];
    p.schedule.liquidatedDamages = "$500 per dock per hour if not released at 5:00 AM, capped at $2,500/night.";
    p.insurance.safety.unshift("Sawcutting: wet cut only. Slurry contained. No slurry in the drain.");
  },
  Electrical: (p) => {
    p.invitation.packageNo = "26A";
    p.scope.baseItems = [
      "Provide complete electrical for the areas shown, including demo of abandoned circuits.",
      "New branch circuits, devices, and lighting as scheduled.",
      "Coordinate shutdowns with the superintendent 48 hours in advance.",
      "Label panels. Test and certify before turnover.",
    ];
    p.scope.excluded = ["Utility company charges.", "Fire alarm unless shown.", "Low-voltage data cabling unless listed."];
    p.specs = [
      { id: uid(), title: "Code", detail: "NEC current cycle adopted by the AHJ." },
      { id: uid(), title: "Gear", detail: "Match existing manufacturer where adding to a panel." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Mobilization", qty: "1", unit: "LS" },
      { id: uid(), description: "Demo / safe-off", qty: "1", unit: "LS" },
      { id: uid(), description: "New devices / lighting", qty: "", unit: "LS" },
    ];
  },
  "HVAC / mechanical": (p) => {
    p.invitation.packageNo = "23A";
    p.scope.baseItems = [
      "Remove and replace equipment shown. Protect occupied space from dust and condensate.",
      "Reconnect existing piping, power, and controls unless noted as new.",
      "Startup, test, and balance as specified.",
    ];
    p.scope.excluded = ["Structural steel for new pads unless shown.", "Electrical feeder upgrades by others."];
    p.specs = [
      { id: uid(), title: "Refrigerant", detail: "Recover per EPA. No venting." },
      { id: uid(), title: "Warranty", detail: "One year labor, manufacturer parts." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Mobilization / protection", qty: "1", unit: "LS" },
      { id: uid(), description: "Equipment set / reconnect", qty: "1", unit: "LS" },
      { id: uid(), description: "Startup / TAB", qty: "1", unit: "LS" },
    ];
  },
  Painting: (p) => {
    p.invitation.packageNo = "09A";
    p.scope.baseItems = [
      "Prep, prime, and paint surfaces scheduled. Protect floors, fixtures, and merchandise.",
      "Occupied-area work after hours unless noted.",
    ];
    p.scope.excluded = ["Wallcovering.", "High-performance floor coatings unless listed."];
    p.specs = [
      { id: uid(), title: "Products", detail: "Owner-approved system. Submit product data with the bid if substituting." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Prep / protection", qty: "1", unit: "LS" },
      { id: uid(), description: "Paint scheduled surfaces", qty: "", unit: "SF" },
    ];
  },
  Roofing: (p) => {
    p.invitation.packageNo = "07A";
    p.invitation.workWindow = "Daytime, weather permitting. No work over occupied sales floor without a written plan.";
    p.scope.baseItems = [
      "Tear off to the deck in the areas shown. Install specified membrane, flashings, and accessories.",
      "Daily watertight — no open roof overnight.",
    ];
    p.scope.excluded = ["HVAC disconnect/reconnect by mechanical.", "Interior damage from pre-existing leaks."];
    p.specs = [
      { id: uid(), title: "System", detail: "Manufacturer 20-year NDL or equal. Letter of intent with bid." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Tear-off / haul", qty: "", unit: "SF" },
      { id: uid(), description: "New membrane / flashings", qty: "", unit: "SF" },
    ];
  },
  "Sitework / paving": (p) => {
    p.invitation.packageNo = "31A";
    p.scope.baseItems = [
      "Sawcut, remove, and replace pavement in the hatched areas. Match existing grades for drainage.",
      "Stripe to match existing unless a restripe plan is issued.",
    ];
    p.scope.excluded = ["Underground utilities not shown.", "Landscape restoration beyond disturbed edge."];
    p.specs = [
      { id: uid(), title: "Asphalt", detail: "Mix per local DOT equivalent. Compaction tests by GC." },
    ];
    p.bidForm.lines = [
      { id: uid(), description: "Demo / haul", qty: "", unit: "SF" },
      { id: uid(), description: "New paving", qty: "", unit: "SF" },
      { id: uid(), description: "Striping", qty: "1", unit: "LS" },
    ];
  },
  "General trades": (p) => {
    p.invitation.packageNo = "01A";
    p.scope.baseItems = [
      "Perform the work described in this package complete, including protection, cleanup, and punch.",
    ];
    p.scope.excluded = ["Work shown on other trade packages."];
  },
};

export function newPackage(trade: Trade, company: CompanyProfile): BidPackage {
  const p = basePackage(trade, company);
  TRADE_FILL[trade](p);
  return p;
}

export const SAMPLE_ID = "sample-atlas-1847";

export function samplePackage(): BidPackage {
  const company: CompanyProfile = {
    name: "Redrock Field Services",
    legalName: "Redrock Field Services, LLC",
    address: "410 W 300 S, Ste 220",
    city: "Salt Lake City",
    state: "UT",
    zip: "84101",
    phone: "801-555-0144",
    email: "druiz@redrockfield.example",
    bidsEmail: "bids@redrockfield.example",
    website: "",
  };
  const p = newPackage("Concrete repair", company);
  p.id = SAMPLE_ID;
  p.status = "issued";
  p.invitation.projectName = "Atlas Fresh #1847 — Receiving Dock & Apron Repairs";
  p.invitation.siteId = "Atlas Fresh #1847";
  p.invitation.address = "8821 W Pioneer Rd, West Jordan, UT 84088";
  p.invitation.owner = "Atlas Fresh Markets, Inc.";
  p.invitation.projectNo = "RFS-26-441";
  p.invitation.packageNo = "03A";
  p.invitation.rfiDue = "2026-09-28";
  p.invitation.bidDue = "2026-10-02";
  p.invitation.bidDueTime = "2:00 PM MT";
  p.invitation.awardNotify = "2026-10-03";
  p.invitation.workWindow = "Oct 19 – Nov 8, 2026 · 10:00 PM – 5:00 AM";
  p.project.buildingStatus = "Occupied grocery — receiving dock remains live";
  p.project.workArea = "11,800 SF apron + 420 LF joints + 7 column bases";
  p.project.existingConditions = "Existing 6\" unreinforced / lightly reinforced dock slab, ~2009";
  p.project.access = "West receiving yard only. No customer parking lot staging.";
  p.contacts = [
    {
      id: uid(),
      role: "Project manager",
      name: "Dana Ruiz",
      email: "druiz@redrockfield.example",
      phone: "801-555-0144",
      notes: "",
    },
    {
      id: uid(),
      role: "Superintendent",
      name: "Cole Maddox",
      email: "cmaddox@redrockfield.example",
      phone: "801-555-0192",
      notes: "",
    },
    {
      id: uid(),
      role: "Estimator / bids",
      name: "Bids desk",
      email: "bids@redrockfield.example",
      phone: "",
      notes: "",
    },
    {
      id: uid(),
      role: "Owner facilities",
      name: "Atlas Fresh — Store Planning",
      email: "facilities@atlasfresh.example",
      phone: "",
      notes: "",
    },
  ];
  p.bidForm.lines = [
    { id: uid(), description: "Mobilization / night setup / protection", qty: "1", unit: "LS" },
    { id: uid(), description: "Apron panel remove & replace", qty: "4,250", unit: "SF" },
    { id: uid(), description: "Joint route / clean / polyurea fill", qty: "420", unit: "LF" },
    { id: uid(), description: "Column-base spall repairs", qty: "7", unit: "EA" },
    { id: uid(), description: "Dock 5 drain re-pitch", qty: "1", unit: "LS" },
    { id: uid(), description: "Haul-off / dump fees beyond GC box", qty: "1", unit: "LS" },
  ];
  p.drawings.notes =
    "Joints: existing grid, 420 LF to route and fill. Hatched panels at Docks 3–6 = remove & replace (4,250 SF). Scale is diagrammatic — field-measure.";
  p.drawings.missing = "Full civil CAD and spec section 03 01 30 issue with the file link on a live job.";
  p.schedule.phases = [
    { id: uid(), name: "A", nights: "2", work: "Joints at Docks 1–2 (live docks — small tools only)" },
    { id: uid(), name: "B", nights: "4", work: "Remove/replace apron panels Docks 3–4" },
    { id: uid(), name: "C", nights: "4", work: "Remove/replace apron panels Docks 5–6 + drain re-pitch" },
    { id: uid(), name: "D", nights: "2", work: "Column bases + punch / joint filler at new saw cuts" },
  ];
  p.insurance.certificateHolder = "Redrock Field Services, 410 W 300 S, Ste 220, Salt Lake City, UT 84101";
  p.insurance.additionalInsured =
    "Redrock Field Services, LLC and Atlas Fresh Markets, Inc. Primary and non-contributory. Waiver of subrogation on GL, auto, and workers’ comp.";
  p.createdAt = "2026-09-17T15:00:00.000Z";
  p.updatedAt = "2026-09-17T15:00:00.000Z";
  p.invitation.documentsIssued = "2026-09-17";
  p.contacts.forEach((c, i) => {
    c.id = `s-c-${i}`;
  });
  p.bidForm.lines.forEach((l, i) => {
    l.id = `s-l-${i}`;
  });
  p.bidForm.changePrices.forEach((l, i) => {
    l.id = `s-u-${i}`;
  });
  p.specs.forEach((s, i) => {
    s.id = `s-sp-${i}`;
  });
  p.insurance.coverages.forEach((c, i) => {
    c.id = `s-ins-${i}`;
  });
  p.schedule.phases.forEach((ph, i) => {
    ph.id = `s-ph-${i}`;
  });
  return p;
}

export const ATTERBURY_ID = "ifb-atterbury-cain-26-b-012";

export function leadMagnetCompany(): CompanyProfile {
  return {
    name: "Lead Magnet",
    legalName: "Lead Magnet",
    address: "",
    city: "",
    state: "",
    zip: "",
    phone: "855-799-8420",
    email: "",
    bidsEmail: "",
    website: "",
  };
}

export function issuerForPackage(pack: BidPackage, fallback: CompanyProfile): CompanyProfile {
  if (pack.id === ATTERBURY_ID) return leadMagnetCompany();
  return fallback;
}

export function isLeadMagnet(company: CompanyProfile) {
  return /lead magnet/i.test(`${company.name} ${company.legalName}`);
}

export const ATTERBURY_FOLLOW_UP = `Email: 8 open concrete bids in Indiana — nearest deadline Aug 25.

Best fit: Camp Atterbury covered training area (MDI-CAIN-26-B-012), Edinburgh IN. Slab / foundations on a new covered training facility. Due Sep 9. Elysia Justice · contractingpublicbid@ago.in.gov · (317) 552-1674

We attached a Lead Magnet invitation to bid for that one. If you want help filling it out or have questions, call 855-799-8420.`;

export function followUpText(pack: BidPackage) {
  if (pack.id === ATTERBURY_ID) return ATTERBURY_FOLLOW_UP;
  const inv = pack.invitation;
  const name = inv.projectName || "this job";
  const due = inv.bidDue ? ` Due ${inv.bidDue}.` : "";
  const poc = pack.contacts.find((c) => c.email || c.phone);
  const pocLine = poc
    ? `${poc.name}${poc.email ? ` · ${poc.email}` : ""}${poc.phone ? ` · ${poc.phone}` : ""}`
    : "";
  return `Email: we sent you the open-bid digest.

Best fit: ${name}.${due}${pocLine ? ` ${pocLine}` : ""}

We attached a Lead Magnet invitation to bid for that one. If you want help filling it out or have questions, call 855-799-8420.`;
}

export function atterburyPackage(): BidPackage {
  const p = newPackage("General trades", leadMagnetCompany());
  p.id = ATTERBURY_ID;
  p.status = "issued";
  p.trade = "Concrete repair";
  p.invitation.projectName = "Camp Atterbury Covered Training Area Facility";
  p.invitation.siteId = "Camp Atterbury";
  p.invitation.address = "232 Eggleston St, Edinburgh, IN 46124";
  p.invitation.owner = "Indiana Army National Guard / State Armory Board";
  p.invitation.occupied = true;
  p.invitation.packageNo = "03A";
  p.invitation.projectNo = "MDI-CAIN-26-B-012";
  p.invitation.documentsIssued = "2026-08-12";
  p.invitation.rfiDue = "";
  p.invitation.bidDue = "2026-09-09";
  p.invitation.bidDueTime = "9:00 AM ET";
  p.invitation.awardNotify = "";
  p.invitation.workWindow = "Per IFB / installation access. Confirm hours and badging with DPW.";
  p.invitation.submitTo = "contractingpublicbid@ago.in.gov";
  p.invitation.submitNotes =
    "This invitation is issued by Lead Magnet. It is a working package to help you bid. Email the official bid PDF to contractingpublicbid@ago.in.gov, attn Elysia Justice, Deputy State Contracting Officer. Subject: MDI-CAIN-26-B-012 / [Your Company]. Include signed bid form, 5% bid bond, IDOA Certificate of Qualification 1542.04 (INDOT prequalification does not satisfy this), license, and current COI. Pull the official drawings from the Armory Board bid-posting page before you price. Questions on this Lead Magnet package: 855-799-8420.";
  p.project.buildingStatus = "Active military training installation — occupied, badged access";
  p.project.workArea =
    "Covered training-area facility. Building work over $150,000. Concrete package: slab-on-grade, foundations, and related flatwork as shown in the IFB.";
  p.project.existingConditions =
    "New covered training-area facility. Field-verify existing grade, utilities, and pad limits against the IFB drawings. Do not assume INDOT spec.";
  p.project.access =
    "Camp Atterbury gate. Expect ID, vehicle search, and escort. No work, deliveries, or site walk without installation access. Coordinate with DPW.";
  p.project.dumpster =
    "Contractor provides haul-off unless the IFB assigns a dumpster. No spoils left on the installation.";
  p.project.permits =
    "Public IFB. Contractor holds IDOA Certificate of Qualification 1542.04. Trade permits if the IFB assigns them.";
  p.project.prevailingWage =
    "Public work over $150,000. Confirm the wage determination in the IFB. IDOA 1542.04 required — INDOT prequal does not count.";
  p.project.tax = "Show tax separately if the IFB requires it. Confirm owner tax-exempt status in the package.";
  p.contacts = [
    {
      id: "att-c-0",
      role: "Issued by",
      name: "Lead Magnet",
      email: "",
      phone: "855-799-8420",
      notes: "This working invitation is from Lead Magnet, not from the owner.",
    },
    {
      id: "att-c-1",
      role: "Contracting officer (official IFB)",
      name: "Elysia Justice, Deputy State Contracting Officer",
      email: "contractingpublicbid@ago.in.gov",
      phone: "(317) 552-1674",
      notes: "Official bids go here. This is the owner POC, not Lead Magnet.",
    },
  ];
  p.documentsList = [
    "01 Invitation to Bid — issued by Lead Magnet",
    "02 Project Data & Contacts",
    "03 Scope of Work — Package 03A Concrete",
    "04 Bid Form (required)",
    "05 Insurance, Bond & Safety Minimums",
    "06 Work Restrictions / Schedule",
    "07 Drawing / spec notes — official IFB from Armory Board bid posting",
  ];
  p.scope.baseItems = [
    "Furnish labor, equipment, and materials for the concrete associated with the covered training-area facility as shown in IFB MDI-CAIN-26-B-012.",
    "Foundations, footings, and slab-on-grade for the building. Match elevations, thickness, and reinforcing on the drawings.",
    "Related pads, sidewalks, and miscellaneous concrete tied to this facility if shown.",
    "Mobilize to a controlled military installation. Comply with gate, badging, escort, and photo restrictions.",
    "Place, finish, cure, and protect new concrete. Saw joints to the layout on the drawings.",
    "Haul-off of spoils and daily cleanup. No material stored outside the approved laydown.",
  ];
  p.scope.included = [
    "Concrete, rebar, mesh, vapor barrier, formwork, and curing as required by the IFB for this package.",
    "Testing (cylinders / slump) unless the IFB assigns it to the owner.",
    "Premium time if the installation restricts work to nights or weekends.",
    "5% bid bond with the bid.",
  ];
  p.scope.excluded = [
    "Structural steel, metal building, and architectural work (other primes / other packages).",
    "MEP, fire protection, and low-voltage.",
    "Work not shown in MDI-CAIN-26-B-012.",
    "Hazardous-material abatement — stop and notify the contracting officer.",
  ];
  p.scope.unitPriceNotes = [
    "Additional foundation concrete per CY.",
    "Additional slab-on-grade per SF.",
    "Additional sidewalk / pad per SF.",
    "Standby hourly rate if the installation holds the site through no fault of the contractor.",
  ];
  p.specs = [
    {
      id: "att-sp-0",
      title: "Governing documents",
      detail:
        "This invitation is issued by Lead Magnet as a working package. The official IFB, drawings, and specs on the Armory Board bid-posting page govern. Do not treat this document as an owner-issued solicitation.",
    },
    {
      id: "att-sp-1",
      title: "Concrete",
      detail: "Mix, reinforcing, and finish per the IFB spec. Do not substitute INDOT pay items unless the drawings say so.",
    },
    {
      id: "att-sp-2",
      title: "Qualification",
      detail: "IDOA Certificate of Qualification 1542.04 required with the bid. INDOT prequalification does not satisfy this.",
    },
    {
      id: "att-sp-3",
      title: "Bond",
      detail: "5% bid bond with the bid. Performance and payment bonds per the IFB if awarded.",
    },
  ];
  p.bidForm.lines = [
    { id: "att-l-0", description: "Mobilization / badging / protection", qty: "1", unit: "LS" },
    { id: "att-l-1", description: "Foundations / footings", qty: "", unit: "CY" },
    { id: "att-l-2", description: "Slab-on-grade", qty: "", unit: "SF" },
    { id: "att-l-3", description: "Related pads / sidewalks / miscellaneous concrete", qty: "", unit: "SF" },
    { id: "att-l-4", description: "Testing / curing / protection", qty: "1", unit: "LS" },
    { id: "att-l-5", description: "Haul-off", qty: "1", unit: "LS" },
  ];
  p.bidForm.changePrices = [
    { id: "att-u-0", description: "Additional foundation concrete", qty: "", unit: "CY" },
    { id: "att-u-1", description: "Additional slab-on-grade", qty: "", unit: "SF" },
    { id: "att-u-2", description: "Additional sidewalk / pad", qty: "", unit: "SF" },
    { id: "att-u-3", description: "Crew standby, installation delay", qty: "", unit: "HR" },
  ];
  p.bidForm.acknowledgements = [
    "I understand this invitation was issued by Lead Magnet. I will download the official IFB, drawings, and specs from the Armory Board bid-posting page before I submit.",
    "I hold, or will hold at bid time, IDOA Certificate of Qualification 1542.04. I understand INDOT prequal does not count.",
    "I attach a 5% bid bond.",
    "I can staff the hours and access rules on the schedule page.",
    "I can furnish the insurance limits within 5 days of notice of award.",
    "This bid is firm for 30 days. No deposit or off-contract payment is requested.",
  ];
  p.insurance.additionalInsured =
    "The State of Indiana, the Indiana Army National Guard, and the State Armory Board, primary and non-contributory. Waiver of subrogation on GL, auto, and workers’ compensation.";
  p.insurance.certificateHolder =
    "Indiana Army National Guard / State Armory Board, 232 Eggleston St, Edinburgh, IN 46124";
  p.insurance.bondThreshold = "0";
  p.insurance.bondNotes = [
    "5% bid bond is required with every bid on this IFB.",
    "If awarded, performance and payment bonds per the IFB (typically 100% of the contract).",
    "Surety must be admitted in Indiana.",
    "IDOA Certificate of Qualification 1542.04 is separate from bonding. Attach both.",
  ];
  p.insurance.safety = [
    "Military installation: follow gate, escort, and no-photo rules. No weapons on site.",
    "Hard hats, hi-vis, and eye protection on site.",
    "Report any injury, property strike, or security incident to DPW and the contracting officer before the shift ends.",
    "Sawcutting: wet cut only. Contain slurry. No slurry in installation drains.",
  ];
  p.schedule.hours = [
    "Work hours per the IFB and Camp Atterbury DPW. Do not assume a civilian 7–3.",
    "Gate wait is on the contractor. Build it into mobilization — it is not a change order.",
  ];
  p.schedule.operations = [
    "Active training may close roads or the pad without notice. Have a standby plan.",
    "Deliveries only through the approved gate and only with a named escort.",
    "No personal vehicles in the training area.",
  ];
  p.schedule.phases = [
    { id: "att-ph-0", name: "A", nights: "—", work: "Layout, excavation, foundations / footings" },
    { id: "att-ph-1", name: "B", nights: "—", work: "Slab-on-grade, joints, cure" },
    { id: "att-ph-2", name: "C", nights: "—", work: "Pads / sidewalks / miscellaneous concrete" },
    { id: "att-ph-3", name: "D", nights: "—", work: "Punch, test reports, turnover" },
  ];
  p.schedule.bidderQuestions = [
    "Is a pre-bid walk required, and who badges visitors?",
    "Confirm bid-due time on Sep 9 (digest lists the date; paving IFBs on this board have used 9:00 a.m. email / 10:00 a.m. read-aloud — verify for B-012).",
    "Who owns testing — contractor or owner?",
    "Are there restricted-photo or foreign-national rules that affect the crew list?",
  ];
  p.schedule.liquidatedDamages = "Per the IFB. Do not price liquidated damages from this working copy.";
  p.drawings.notes =
    "Official drawings and specs are on the Armory Board bid-posting page. Lead Magnet did not attach CAD. Field-measure; do not bid from this summary alone.";
  p.drawings.missing =
    "IFB drawings, spec book, wage determination, and bid-bond form — download from https://www.in.gov/indiana-national-guard/adjutant-generals-office/armory-board/bid-posting/";
  p.addenda = [];
  p.createdAt = "2026-08-23T20:16:09.000Z";
  p.updatedAt = "2026-08-23T20:16:09.000Z";
  p.insurance.coverages.forEach((c, i) => {
    c.id = `att-ins-${i}`;
  });
  return p;
}
