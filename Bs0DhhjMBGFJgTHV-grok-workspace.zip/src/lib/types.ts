export type PackageStatus = "draft" | "issued" | "closed";

export type Contact = {
  id: string;
  role: string;
  name: string;
  email: string;
  phone: string;
  notes: string;
};

export type ScopeBlock = {
  baseItems: string[];
  included: string[];
  excluded: string[];
  unitPriceNotes: string[];
};

export type SpecItem = {
  id: string;
  title: string;
  detail: string;
};

export type BidLine = {
  id: string;
  description: string;
  qty: string;
  unit: string;
};

export type Coverage = {
  id: string;
  coverage: string;
  limit: string;
  notes: string;
};

export type Phase = {
  id: string;
  name: string;
  nights: string;
  work: string;
};

export type Addendum = {
  id: string;
  number: string;
  date: string;
  summary: string;
};

export type CompanyProfile = {
  name: string;
  legalName: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  phone: string;
  email: string;
  bidsEmail: string;
  website: string;
};

export type BidPackage = {
  id: string;
  createdAt: string;
  updatedAt: string;
  status: PackageStatus;
  trade: string;
  invitation: {
    projectName: string;
    siteId: string;
    address: string;
    owner: string;
    occupied: boolean;
    packageNo: string;
    projectNo: string;
    documentsIssued: string;
    rfiDue: string;
    bidDue: string;
    bidDueTime: string;
    awardNotify: string;
    workWindow: string;
    submitTo: string;
    submitNotes: string;
  };
  project: {
    buildingStatus: string;
    workArea: string;
    existingConditions: string;
    access: string;
    dumpster: string;
    permits: string;
    prevailingWage: string;
    tax: string;
  };
  contacts: Contact[];
  documentsList: string[];
  scope: ScopeBlock;
  drawings: {
    notes: string;
    missing: string;
  };
  specs: SpecItem[];
  bidForm: {
    lines: BidLine[];
    changePrices: BidLine[];
    acknowledgements: string[];
  };
  insurance: {
    coverages: Coverage[];
    additionalInsured: string;
    certificateHolder: string;
    bondThreshold: string;
    bondNotes: string[];
    safety: string[];
  };
  schedule: {
    hours: string[];
    operations: string[];
    phases: Phase[];
    bidderQuestions: string[];
    liquidatedDamages: string;
  };
  addenda: Addendum[];
};

export const TRADES = [
  "Concrete repair",
  "Electrical",
  "HVAC / mechanical",
  "Painting",
  "Roofing",
  "Sitework / paving",
  "General trades",
] as const;

export type Trade = (typeof TRADES)[number];
