import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { uid } from "@/lib/utils";

export function StringList({
  items,
  onChange,
  placeholder = "Add a line",
  multiline = false,
}: {
  items: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  multiline?: boolean;
}) {
  const rows = items.length ? items : [""];
  return (
    <div className="flex flex-col gap-2">
      {rows.map((item, i) => {
        const Comp = multiline ? Textarea : Input;
        return (
          <div key={i} className="flex gap-2">
            <Comp
              value={item}
              placeholder={placeholder}
              onChange={(e) => {
                const next = [...rows];
                next[i] = e.target.value;
                onChange(next);
              }}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="shrink-0 text-muted hover:text-danger"
              onClick={() => onChange(rows.filter((_, j) => j !== i))}
              aria-label="Remove line"
            >
              <Trash2 />
            </Button>
          </div>
        );
      })}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="self-start"
        onClick={() => onChange([...rows, ""])}
      >
        <Plus />
        Add line
      </Button>
    </div>
  );
}

export function keyedList<T extends { id: string }>(
  rows: T[],
  blank: () => Omit<T, "id">,
  onChange: (next: T[]) => void,
) {
  return {
    add: () => onChange([...rows, { id: uid(), ...blank() } as T]),
    remove: (id: string) => onChange(rows.filter((r) => r.id !== id)),
    patch: (id: string, patch: Partial<T>) =>
      onChange(rows.map((r) => (r.id === id ? { ...r, ...patch } : r))),
  };
}
