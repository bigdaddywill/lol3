import { useEffect } from "react";
import { useBinder } from "@/lib/store";

export function BinderHydrate() {
  useEffect(() => {
    useBinder.getState().hydrateFromStorage();
  }, []);
  return null;
}
