import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { StringList, keyedList } from "@/components/list-editor";
import type { BidPackage } from "@/lib/types";
import { uid } from "@/lib/utils";

const SECTIONS = [
  { id: "invite", label: "01 Invitation" },
  { id: "project", label: "02 Project" },
  { id: "contacts", label: "03 Contacts" },
  { id: "scope", label: "04 Scope" },
  { id: "bidform", label: "05 Bid form" },
  { id: "insurance", label: "06 Insurance" },
  { id: "schedule", label: "07 Schedule" },
  { id: "drawings", label: "08 Drawings & specs" },
  { id: "addenda", label: "09 Addenda" },
] as const;

export type SectionId = (typeof SECTIONS)[number]["id"];
export { SECTIONS };

export function PackageEditor({
  pack,
  onChange,
  section,
}: {
  pack: BidPackage;
  onChange: (p: BidPackage) => void;
  section: SectionId;
}) {
  const set = (patch: Partial<BidPackage>) => onChange({ ...pack, ...patch });

  return (
    <div className="flex flex-col gap-5">
      {section === "invite" && (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Project name" className="sm:col-span-2">
            <Input
              value={pack.invitation.projectName}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, projectName: e.target.value } })
              }
            />
          </Field>
          <Field label="Site / store ID">
            <Input
              value={pack.invitation.siteId}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, siteId: e.target.value } })
              }
            />
          </Field>
          <Field label="Project number">
            <Input
              value={pack.invitation.projectNo}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, projectNo: e.target.value } })
              }
            />
          </Field>
          <Field label="Address" className="sm:col-span-2">
            <Input
              value={pack.invitation.address}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, address: e.target.value } })
              }
            />
          </Field>
          <Field label="Owner">
            <Input
              value={pack.invitation.owner}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, owner: e.target.value } })
              }
            />
          </Field>
          <Field label="Package no.">
            <Input
              value={pack.invitation.packageNo}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, packageNo: e.target.value } })
              }
            />
          </Field>
          <label className="flex h-11 items-end gap-2 pb-1 text-sm text-fg">
            <input
              type="checkbox"
              className="size-4 accent-navy"
              checked={pack.invitation.occupied}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, occupied: e.target.checked } })
              }
            />
            Occupied building
          </label>
          <Field label="Documents issued">
            <Input
              type="date"
              value={pack.invitation.documentsIssued}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, documentsIssued: e.target.value } })
              }
            />
          </Field>
          <Field label="RFI due">
            <Input
              type="date"
              value={pack.invitation.rfiDue}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, rfiDue: e.target.value } })
              }
            />
          </Field>
          <Field label="Bids due">
            <Input
              type="date"
              value={pack.invitation.bidDue}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, bidDue: e.target.value } })
              }
            />
          </Field>
          <Field label="Bid time">
            <Input
              value={pack.invitation.bidDueTime}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, bidDueTime: e.target.value } })
              }
            />
          </Field>
          <Field label="Award notify">
            <Input
              type="date"
              value={pack.invitation.awardNotify}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, awardNotify: e.target.value } })
              }
            />
          </Field>
          <Field label="Work window" className="sm:col-span-2">
            <Input
              value={pack.invitation.workWindow}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, workWindow: e.target.value } })
              }
            />
          </Field>
          <Field label="Submit bids to (email)" className="sm:col-span-2">
            <Input
              value={pack.invitation.submitTo}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, submitTo: e.target.value } })
              }
            />
          </Field>
          <Field label="Submit notes" className="sm:col-span-2">
            <Textarea
              rows={4}
              value={pack.invitation.submitNotes}
              onChange={(e) =>
                set({ invitation: { ...pack.invitation, submitNotes: e.target.value } })
              }
            />
          </Field>
        </div>
      )}

      {section === "project" && (
        <div className="grid gap-3">
          {(
            [
              ["buildingStatus", "Building status"],
              ["workArea", "Work area / quantities"],
              ["existingConditions", "Existing conditions"],
              ["access", "Access"],
              ["dumpster", "Dumpster / washout"],
              ["permits", "Permits"],
              ["prevailingWage", "Prevailing wage"],
              ["tax", "Tax"],
            ] as const
          ).map(([key, label]) => (
            <Field key={key} label={label}>
              <Textarea
                rows={2}
                value={pack.project[key]}
                onChange={(e) =>
                  set({ project: { ...pack.project, [key]: e.target.value } })
                }
              />
            </Field>
          ))}
        </div>
      )}

      {section === "contacts" && (
        <div className="flex flex-col gap-4">
          {pack.contacts.map((c) => (
            <div key={c.id} className="grid gap-2 rounded-lg border border-line bg-surface p-3 sm:grid-cols-2">
              <Field label="Role">
                <Input
                  value={c.role}
                  onChange={(e) =>
                    set({
                      contacts: pack.contacts.map((x) =>
                        x.id === c.id ? { ...x, role: e.target.value } : x,
                      ),
                    })
                  }
                />
              </Field>
              <Field label="Name">
                <Input
                  value={c.name}
                  onChange={(e) =>
                    set({
                      contacts: pack.contacts.map((x) =>
                        x.id === c.id ? { ...x, name: e.target.value } : x,
                      ),
                    })
                  }
                />
              </Field>
              <Field label="Email">
                <Input
                  value={c.email}
                  onChange={(e) =>
                    set({
                      contacts: pack.contacts.map((x) =>
                        x.id === c.id ? { ...x, email: e.target.value } : x,
                      ),
                    })
                  }
                />
              </Field>
              <Field label="Phone">
                <Input
                  value={c.phone}
                  onChange={(e) =>
                    set({
                      contacts: pack.contacts.map((x) =>
                        x.id === c.id ? { ...x, phone: e.target.value } : x,
                      ),
                    })
                  }
                />
              </Field>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-danger sm:col-span-2"
                onClick={() =>
                  set({ contacts: pack.contacts.filter((x) => x.id !== c.id) })
                }
              >
                <Trash2 />
                Remove contact
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="self-start"
            onClick={() =>
              set({
                contacts: [
                  ...pack.contacts,
                  { id: uid(), role: "", name: "", email: "", phone: "", notes: "" },
                ],
              })
            }
          >
            <Plus />
            Add contact
          </Button>
        </div>
      )}

      {section === "scope" && (
        <div className="flex flex-col gap-5">
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Base work
            </p>
            <StringList
              multiline
              items={pack.scope.baseItems}
              onChange={(baseItems) => set({ scope: { ...pack.scope, baseItems } })}
            />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Included
            </p>
            <StringList
              items={pack.scope.included}
              onChange={(included) => set({ scope: { ...pack.scope, included } })}
            />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Excluded
            </p>
            <StringList
              items={pack.scope.excluded}
              onChange={(excluded) => set({ scope: { ...pack.scope, excluded } })}
            />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Unit-price notes
            </p>
            <StringList
              items={pack.scope.unitPriceNotes}
              onChange={(unitPriceNotes) =>
                set({ scope: { ...pack.scope, unitPriceNotes } })
              }
            />
          </div>
        </div>
      )}

      {section === "bidform" && (
        <div className="flex flex-col gap-5">
          <p className="text-sm text-muted">
            Quantities you fill. Unit prices stay blank for the sub.
          </p>
          <LineTable
            rows={pack.bidForm.lines}
            onChange={(lines) => set({ bidForm: { ...pack.bidForm, lines } })}
          />
          <p className="text-xs font-medium uppercase tracking-wide text-muted">
            Change-order unit prices
          </p>
          <LineTable
            rows={pack.bidForm.changePrices}
            onChange={(changePrices) =>
              set({ bidForm: { ...pack.bidForm, changePrices } })
            }
            hideQty
          />
          <p className="text-xs font-medium uppercase tracking-wide text-muted">
            Acknowledgements
          </p>
          <StringList
            items={pack.bidForm.acknowledgements}
            onChange={(acknowledgements) =>
              set({ bidForm: { ...pack.bidForm, acknowledgements } })
            }
          />
        </div>
      )}

      {section === "insurance" && (
        <div className="flex flex-col gap-4">
          {pack.insurance.coverages.map((c) => (
            <div key={c.id} className="grid gap-2 rounded-lg border border-line bg-surface p-3 sm:grid-cols-3">
              <Field label="Coverage" className="sm:col-span-3">
                <Input
                  value={c.coverage}
                  onChange={(e) =>
                    set({
                      insurance: {
                        ...pack.insurance,
                        coverages: pack.insurance.coverages.map((x) =>
                          x.id === c.id ? { ...x, coverage: e.target.value } : x,
                        ),
                      },
                    })
                  }
                />
              </Field>
              <Field label="Limit" className="sm:col-span-2">
                <Input
                  value={c.limit}
                  onChange={(e) =>
                    set({
                      insurance: {
                        ...pack.insurance,
                        coverages: pack.insurance.coverages.map((x) =>
                          x.id === c.id ? { ...x, limit: e.target.value } : x,
                        ),
                      },
                    })
                  }
                />
              </Field>
              <Field label="Notes">
                <Input
                  value={c.notes}
                  onChange={(e) =>
                    set({
                      insurance: {
                        ...pack.insurance,
                        coverages: pack.insurance.coverages.map((x) =>
                          x.id === c.id ? { ...x, notes: e.target.value } : x,
                        ),
                      },
                    })
                  }
                />
              </Field>
            </div>
          ))}
          <Field label="Additional insured">
            <Textarea
              value={pack.insurance.additionalInsured}
              onChange={(e) =>
                set({
                  insurance: { ...pack.insurance, additionalInsured: e.target.value },
                })
              }
            />
          </Field>
          <Field label="Certificate holder">
            <Input
              value={pack.insurance.certificateHolder}
              onChange={(e) =>
                set({
                  insurance: { ...pack.insurance, certificateHolder: e.target.value },
                })
              }
            />
          </Field>
          <Field label="Bond threshold (USD)">
            <Input
              value={pack.insurance.bondThreshold}
              onChange={(e) =>
                set({
                  insurance: { ...pack.insurance, bondThreshold: e.target.value },
                })
              }
            />
          </Field>
          <p className="text-xs font-medium uppercase tracking-wide text-muted">Bond notes</p>
          <StringList
            items={pack.insurance.bondNotes}
            onChange={(bondNotes) =>
              set({ insurance: { ...pack.insurance, bondNotes } })
            }
          />
          <p className="text-xs font-medium uppercase tracking-wide text-muted">Safety</p>
          <StringList
            items={pack.insurance.safety}
            onChange={(safety) => set({ insurance: { ...pack.insurance, safety } })}
          />
        </div>
      )}

      {section === "schedule" && (
        <div className="flex flex-col gap-5">
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Hours</p>
            <StringList
              items={pack.schedule.hours}
              onChange={(hours) => set({ schedule: { ...pack.schedule, hours } })}
            />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Operations
            </p>
            <StringList
              items={pack.schedule.operations}
              onChange={(operations) =>
                set({ schedule: { ...pack.schedule, operations } })
              }
            />
          </div>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Phases</p>
            {pack.schedule.phases.map((ph) => {
              const k = keyedList(pack.schedule.phases, () => ({ name: "", nights: "", work: "" }), (phases) =>
                set({ schedule: { ...pack.schedule, phases } }),
              );
              return (
                <div key={ph.id} className="mb-2 grid gap-2 sm:grid-cols-[4rem_5rem_1fr_auto]">
                  <Input
                    value={ph.name}
                    placeholder="A"
                    onChange={(e) => k.patch(ph.id, { name: e.target.value })}
                  />
                  <Input
                    value={ph.nights}
                    placeholder="Nights"
                    onChange={(e) => k.patch(ph.id, { nights: e.target.value })}
                  />
                  <Input
                    value={ph.work}
                    placeholder="Work"
                    onChange={(e) => k.patch(ph.id, { work: e.target.value })}
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => k.remove(ph.id)}>
                    <Trash2 />
                  </Button>
                </div>
              );
            })}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() =>
                set({
                  schedule: {
                    ...pack.schedule,
                    phases: [
                      ...pack.schedule.phases,
                      { id: uid(), name: "", nights: "", work: "" },
                    ],
                  },
                })
              }
            >
              <Plus />
              Add phase
            </Button>
          </div>
          <Field label="Liquidated damages">
            <Textarea
              value={pack.schedule.liquidatedDamages}
              onChange={(e) =>
                set({
                  schedule: { ...pack.schedule, liquidatedDamages: e.target.value },
                })
              }
            />
          </Field>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Bidder questions you will answer
            </p>
            <StringList
              items={pack.schedule.bidderQuestions}
              onChange={(bidderQuestions) =>
                set({ schedule: { ...pack.schedule, bidderQuestions } })
              }
            />
          </div>
        </div>
      )}

      {section === "drawings" && (
        <div className="flex flex-col gap-4">
          <Field label="Drawing / sketch notes for bidders">
            <Textarea
              rows={5}
              value={pack.drawings.notes}
              onChange={(e) =>
                set({ drawings: { ...pack.drawings, notes: e.target.value } })
              }
            />
          </Field>
          <Field label="What is not attached (tell them to ask)">
            <Input
              value={pack.drawings.missing}
              onChange={(e) =>
                set({ drawings: { ...pack.drawings, missing: e.target.value } })
              }
            />
          </Field>
          <p className="text-xs font-medium uppercase tracking-wide text-muted">Specs</p>
          {pack.specs.map((s) => (
            <div key={s.id} className="grid gap-2 sm:grid-cols-[10rem_1fr_auto]">
              <Input
                placeholder="Title"
                value={s.title}
                onChange={(e) =>
                  set({
                    specs: pack.specs.map((x) =>
                      x.id === s.id ? { ...x, title: e.target.value } : x,
                    ),
                  })
                }
              />
              <Input
                placeholder="Requirement"
                value={s.detail}
                onChange={(e) =>
                  set({
                    specs: pack.specs.map((x) =>
                      x.id === s.id ? { ...x, detail: e.target.value } : x,
                    ),
                  })
                }
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => set({ specs: pack.specs.filter((x) => x.id !== s.id) })}
              >
                <Trash2 />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="self-start"
            onClick={() =>
              set({ specs: [...pack.specs, { id: uid(), title: "", detail: "" }] })
            }
          >
            <Plus />
            Add spec
          </Button>
        </div>
      )}

      {section === "addenda" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-muted">
            When the drawings or due date change, add a line. Bidders must price the latest addendum.
          </p>
          {pack.addenda.map((a) => (
            <div key={a.id} className="grid gap-2 sm:grid-cols-[5rem_9rem_1fr_auto]">
              <Input
                placeholder="No."
                value={a.number}
                onChange={(e) =>
                  set({
                    addenda: pack.addenda.map((x) =>
                      x.id === a.id ? { ...x, number: e.target.value } : x,
                    ),
                  })
                }
              />
              <Input
                type="date"
                value={a.date}
                onChange={(e) =>
                  set({
                    addenda: pack.addenda.map((x) =>
                      x.id === a.id ? { ...x, date: e.target.value } : x,
                    ),
                  })
                }
              />
              <Input
                placeholder="Summary"
                value={a.summary}
                onChange={(e) =>
                  set({
                    addenda: pack.addenda.map((x) =>
                      x.id === a.id ? { ...x, summary: e.target.value } : x,
                    ),
                  })
                }
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() =>
                  set({ addenda: pack.addenda.filter((x) => x.id !== a.id) })
                }
              >
                <Trash2 />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="self-start"
            onClick={() =>
              set({
                addenda: [
                  ...pack.addenda,
                  {
                    id: uid(),
                    number: String(pack.addenda.length + 1),
                    date: "",
                    summary: "",
                  },
                ],
              })
            }
          >
            <Plus />
            Add addendum
          </Button>
        </div>
      )}
    </div>
  );
}

function LineTable({
  rows,
  onChange,
  hideQty,
}: {
  rows: BidPackage["bidForm"]["lines"];
  onChange: (rows: BidPackage["bidForm"]["lines"]) => void;
  hideQty?: boolean;
}) {
  return (
    <div className="flex flex-col gap-2">
      {rows.map((l) => (
        <div key={l.id} className="grid grid-cols-[1fr_4.5rem_4rem_auto] gap-2">
          <Input
            placeholder="Description"
            value={l.description}
            onChange={(e) =>
              onChange(rows.map((x) => (x.id === l.id ? { ...x, description: e.target.value } : x)))
            }
          />
          {hideQty ? (
            <div />
          ) : (
            <Input
              placeholder="Qty"
              value={l.qty}
              onChange={(e) =>
                onChange(rows.map((x) => (x.id === l.id ? { ...x, qty: e.target.value } : x)))
              }
            />
          )}
          <Input
            placeholder="Unit"
            value={l.unit}
            onChange={(e) =>
              onChange(rows.map((x) => (x.id === l.id ? { ...x, unit: e.target.value } : x)))
            }
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => onChange(rows.filter((x) => x.id !== l.id))}
          >
            <Trash2 />
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="self-start"
        onClick={() =>
          onChange([...rows, { id: uid(), description: "", qty: "", unit: "" }])
        }
      >
        <Plus />
        Add line
      </Button>
    </div>
  );
}
