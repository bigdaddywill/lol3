import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { useBinder } from "@/lib/store";
import { newPackage } from "@/lib/templates";
import { TRADES, type Trade } from "@/lib/types";

export function NewPackageDialog({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const company = useBinder((s) => s.company);
  const upsert = useBinder((s) => s.upsert);
  const [trade, setTrade] = useState<Trade>("Concrete repair");
  const [name, setName] = useState("");
  const [site, setSite] = useState("");
  const [address, setAddress] = useState("");
  const [due, setDue] = useState("");

  if (!open) return null;

  function create() {
    const p = newPackage(trade, company);
    p.invitation.projectName = name;
    p.invitation.siteId = site;
    p.invitation.address = address;
    p.invitation.bidDue = due;
    if (company.legalName) {
      p.insurance.certificateHolder = [
        company.legalName,
        company.address,
        [company.city, company.state, company.zip].filter(Boolean).join(", "),
      ]
        .filter(Boolean)
        .join(", ");
    }
    upsert(p);
    onClose();
    void navigate({ to: "/package/$id", params: { id: p.id } });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <button
        type="button"
        className="absolute inset-0 bg-navy/50"
        aria-label="Close"
        onClick={onClose}
      />
      <div className="relative z-10 w-full max-w-lg rounded-t-xl border border-line bg-bg p-5 shadow-doc sm:rounded-xl">
        <h2 className="font-display text-xl font-semibold tracking-tight">New bid package</h2>
        <p className="mt-1 text-sm text-muted">
          Pick a trade. Invitation, scope, bid form, and insurance start from that template.
        </p>
        <div className="mt-4 grid gap-3">
          <Field label="Trade">
            <select
              className="flex h-11 w-full rounded-sm border border-line bg-paper px-3 text-sm"
              value={trade}
              onChange={(e) => setTrade(e.target.value as Trade)}
            >
              {TRADES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </Field>
          <Field label="Project name">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Store # — dock repairs" />
          </Field>
          <Field label="Site / store ID">
            <Input value={site} onChange={(e) => setSite(e.target.value)} />
          </Field>
          <Field label="Address">
            <Input value={address} onChange={(e) => setAddress(e.target.value)} />
          </Field>
          <Field label="Bids due">
            <Input type="date" value={due} onChange={(e) => setDue(e.target.value)} />
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={create}>Create package</Button>
        </div>
      </div>
    </div>
  );
}
