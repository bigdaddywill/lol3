import { Check, Download, FileJson, Loader2, MessageSquare } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { downloadPackagePdf } from "@/lib/download-pdf";
import { downloadJson } from "@/lib/files";
import { followUpText, issuerForPackage } from "@/lib/templates";
import type { BidPackage, CompanyProfile } from "@/lib/types";

export function ExportActions({
  pack,
  company,
  compact = false,
}: {
  pack: BidPackage;
  company: CompanyProfile;
  compact?: boolean;
}) {
  const [busy, setBusy] = useState<"pdf" | "json" | "sms" | null>(null);
  const [copied, setCopied] = useState(false);
  const [err, setErr] = useState("");
  const issuer = issuerForPackage(pack, company);

  async function pdf() {
    setErr("");
    setBusy("pdf");
    try {
      await downloadPackagePdf(pack, issuer);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not build the PDF.");
    } finally {
      setBusy(null);
    }
  }

  function json() {
    setErr("");
    setBusy("json");
    try {
      downloadJson(pack, issuer);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not download JSON.");
    } finally {
      setBusy(null);
    }
  }

  async function sms() {
    setErr("");
    setBusy("sms");
    try {
      await navigator.clipboard.writeText(followUpText(pack));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not copy the text.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        size="sm"
        className={compact ? "bg-paper text-navy hover:bg-paper/90" : ""}
        disabled={Boolean(busy)}
        onClick={() => void pdf()}
      >
        {busy === "pdf" ? <Loader2 className="animate-spin" /> : <Download />}
        {busy === "pdf" ? "Building PDF…" : "Download PDF"}
      </Button>
      <Button
        size="sm"
        variant={compact ? "ghost" : "outline"}
        className={compact ? "text-paper hover:bg-paper/10" : ""}
        disabled={Boolean(busy)}
        onClick={() => void sms()}
      >
        {copied ? <Check /> : <MessageSquare />}
        {copied ? "Copied text" : "Copy follow-up"}
      </Button>
      <Button
        size="sm"
        variant={compact ? "ghost" : "outline"}
        className={compact ? "text-paper hover:bg-paper/10" : ""}
        disabled={Boolean(busy)}
        onClick={json}
      >
        {busy === "json" ? <Loader2 className="animate-spin" /> : <FileJson />}
        JSON
      </Button>
      {err ? <span className="text-xs text-danger">{err}</span> : null}
    </div>
  );
}
