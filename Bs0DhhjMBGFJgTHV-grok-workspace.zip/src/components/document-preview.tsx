import type { ReactNode } from "react";
import { isLeadMagnet } from "@/lib/templates";
import type { BidPackage, CompanyProfile } from "@/lib/types";
import { formatDate } from "@/lib/utils";

function gcName(c: CompanyProfile) {
  return c.legalName || c.name || "General Contractor";
}

function Page({
  n,
  total,
  title,
  company,
  projectNo,
  leadMagnet,
  children,
}: {
  n: number;
  total: number;
  title: string;
  company: string;
  projectNo: string;
  leadMagnet: boolean;
  children: ReactNode;
}) {
  return (
    <article className="doc-page relative mx-auto flex min-h-[10.5in] w-full max-w-[8.5in] flex-col bg-paper text-navy shadow-doc print:min-h-0 print:shadow-none">
      <header className="bg-navy px-6 py-3 text-paper">
        <div className="flex items-end justify-between gap-3">
          <p className="font-display text-[11px] font-semibold uppercase tracking-[0.18em]">
            {company}
          </p>
          <p className="text-right font-sans text-[10px] uppercase tracking-wide text-paper/70">
            {leadMagnet ? "Bid invitation" : "Subcontractor bid package"}
            <br />
            {projectNo || "Project no. pending"}
          </p>
        </div>
        <div className="mt-2 h-0.5 w-full bg-stripe" />
      </header>
      <div className="flex items-center justify-between px-6 pt-3 text-[10px] uppercase tracking-wide text-muted">
        <span>{title}</span>
        <span>
          Page {n} of {total}
        </span>
      </div>
      <div className="flex-1 px-6 pb-8 pt-3">{children}</div>
      <footer className="mt-auto border-t border-line bg-surface px-6 py-2 text-center text-[9px] uppercase tracking-wide text-muted">
        {leadMagnet
          ? "Issued by Lead Magnet  ·  Working invitation — official IFB governs  ·  Quantities estimated"
          : "Issued for bidding · Quantities are estimated · Field-measure before pour / install"}
      </footer>
    </article>
  );
}

function H({ children }: { children: ReactNode }) {
  return (
    <h2 className="mb-3 bg-steel px-3 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.14em] text-paper">
      {children}
    </h2>
  );
}

function KV({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="grid grid-cols-[8.5rem_1fr] gap-x-3 border-b border-line/80 py-1.5 text-[12px] leading-snug">
      <dt className="font-semibold text-navy">{k}</dt>
      <dd className="text-ink">{v || "—"}</dd>
    </div>
  );
}

function Bullets({ items }: { items: string[] }) {
  const rows = items.filter((x) => x.trim());
  if (!rows.length) return <p className="text-[12px] text-muted">To be issued.</p>;
  return (
    <ul className="space-y-1.5">
      {rows.map((item, i) => (
        <li key={i} className="flex gap-2 text-[12px] leading-snug text-ink">
          <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-stripe" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function Table({
  headers,
  rows,
}: {
  headers: string[];
  rows: string[][];
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-left text-[11px]">
        <thead>
          <tr className="bg-navy text-paper">
            {headers.map((h) => (
              <th key={h} className="px-2 py-1.5 font-display font-semibold uppercase tracking-wide">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={i % 2 === 0 ? "bg-surface/80" : "bg-paper"}>
              {r.map((c, j) => (
                <td key={j} className="border-b border-line px-2 py-1.5 text-ink">
                  {c || "—"}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function DocumentPreview({
  pack,
  company,
}: {
  pack: BidPackage;
  company: CompanyProfile;
}) {
  const gc = gcName(company);
  const fromLeadMagnet = isLeadMagnet(company);
  const inv = pack.invitation;
  const total = 7;
  const pageProps = { company: gc, projectNo: inv.projectNo, total, leadMagnet: fromLeadMagnet };

  return (
    <div className="doc-stack space-y-6 font-serif print:space-y-0">
      <Page n={1} title="01  —  Invitation to Bid" {...pageProps}>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-navy">
          Invitation to Bid
        </h1>
        <p className="mb-4 text-[12px] text-muted">
          Trade: {pack.trade} · Bid package no. {inv.packageNo || "—"}
        </p>
        {fromLeadMagnet ? (
          <p className="mb-4 border border-navy/20 bg-surface px-3 py-2 text-[12px] leading-relaxed text-ink">
            This invitation is issued by Lead Magnet. It is a working package to help you
            price the job. It is not the official IFB. Official bids go to the contracting
            officer on the contacts page. Questions on this package: 855-799-8420.
          </p>
        ) : null}
        <div className="mb-4 border-l-4 border-stripe bg-surface px-4 py-3">
          <dl>
            <KV k="Project" v={inv.projectName} />
            <KV k="Site ID" v={inv.siteId} />
            <KV k="Address" v={inv.address} />
            <KV k="Owner" v={`${inv.owner}${inv.occupied ? "  (occupied)" : ""}`} />
            <KV k={fromLeadMagnet ? "Issued by" : "General contractor"} v={gc} />
            <KV k={fromLeadMagnet ? "Solicitation no." : "GC project no."} v={inv.projectNo} />
          </dl>
        </div>
        <H>Bid milestones</H>
        <Table
          headers={["Item", "Date / time", "Notes"]}
          rows={[
            ["Documents issued", formatDate(inv.documentsIssued), "This package"],
            ["RFIs due", formatDate(inv.rfiDue), "Email only"],
            ["Bids due", `${formatDate(inv.bidDue)}  ${inv.bidDueTime}`.trim(), "Late bids not opened"],
            ["Apparent low notified", formatDate(inv.awardNotify), "Subject to vetting"],
            ["Work window", inv.workWindow, ""],
          ]}
        />
        <div className="mt-4">
          <H>How to submit</H>
          <p className="mb-2 text-[12px]">
            Email one PDF to <strong>{inv.submitTo || "—"}</strong> with subject:{" "}
            {inv.projectNo || "PROJECT"} / {inv.packageNo || "PKG"} / [Your Company].
          </p>
          <p className="text-[12px] leading-relaxed text-ink">{inv.submitNotes}</p>
        </div>
      </Page>

      <Page n={2} title="02  —  Project Data & Contacts" {...pageProps}>
        <H>Project data</H>
        <Table
          headers={["Field", "Value"]}
          rows={[
            ["Store / site ID", inv.siteId],
            ["Building status", pack.project.buildingStatus],
            ["Work area", pack.project.workArea],
            ["Existing conditions", pack.project.existingConditions],
            ["Access", pack.project.access],
            ["Dumpster / washout", pack.project.dumpster],
            ["Permits", pack.project.permits],
            ["Prevailing wage", pack.project.prevailingWage],
            ["Tax", pack.project.tax],
          ]}
        />
        <div className="mt-4">
          <H>Contacts — use these, not a personal cell as the only record</H>
          <Table
            headers={["Role", "Name", "Email / phone"]}
            rows={pack.contacts.map((c) => [
              c.role,
              c.name,
              [c.email, c.phone].filter(Boolean).join("  ·  "),
            ])}
          />
        </div>
        <div className="mt-4">
          <H>Documents in this package</H>
          <Bullets items={pack.documentsList} />
        </div>
      </Page>

      <Page n={3} title="03  —  Scope of Work" {...pageProps}>
        <H>Base bid — package {inv.packageNo || "—"}</H>
        <Bullets items={pack.scope.baseItems} />
        <div className="mt-4">
          <H>Included</H>
          <Bullets items={pack.scope.included} />
        </div>
        <div className="mt-4">
          <H>Excluded</H>
          <Bullets items={pack.scope.excluded} />
        </div>
        <div className="mt-4">
          <H>Unit prices — used for adds / deducts</H>
          <Bullets items={pack.scope.unitPriceNotes} />
        </div>
      </Page>

      <Page n={4} title="04  —  Bid Form (required)" {...pageProps}>
        <h1 className="mb-1 font-display text-xl font-semibold text-navy">
          Bid Form — Package {inv.packageNo || "—"}
        </h1>
        <p className="mb-4 text-[11px] text-muted">Complete every line. Incomplete forms are not evaluated.</p>
        <div className="mb-4 grid gap-2 text-[12px]">
          <p>Subcontractor legal name: ________________________________</p>
          <p>License no. / classification: ______________________________</p>
          <p>Contact / cell / email: ____________________________________</p>
        </div>
        <H>Price breakout (USD)</H>
        <Table
          headers={["Item", "Qty", "Unit", "Unit price", "Amount"]}
          rows={[
            ...pack.bidForm.lines.map((l) => [l.description, l.qty, l.unit, "$ ________", "$ ________"]),
            ["BASE BID (sum of lines above)", "", "", "", "$ ________"],
            ["Sales tax (if applicable)", "", "", "", "$ ________"],
            ["TOTAL BID", "", "", "", "$ ________"],
          ]}
        />
        <div className="mt-4">
          <H>Unit prices for changes</H>
          <Table
            headers={["Description", "Unit", "Add", "Deduct"]}
            rows={pack.bidForm.changePrices.map((l) => [
              l.description,
              l.unit,
              "$ ________",
              "$ ________",
            ])}
          />
        </div>
        <div className="mt-4">
          <H>Acknowledgements — initial</H>
          <ul className="space-y-2 text-[12px]">
            {pack.bidForm.acknowledgements.filter(Boolean).map((a, i) => (
              <li key={i}>____  {a}</li>
            ))}
          </ul>
        </div>
        <p className="mt-6 text-[12px]">
          Authorized signature: _______________________________    Date: ______________
        </p>
      </Page>

      <Page n={5} title="05  —  Insurance, Bond & Safety" {...pageProps}>
        <H>Certificate of insurance — minimums</H>
        <Table
          headers={["Coverage", "Minimum limit", "Notes"]}
          rows={pack.insurance.coverages.map((c) => [c.coverage, c.limit, c.notes])}
        />
        <p className="mt-3 text-[12px] leading-relaxed">
          Additional insureds: {pack.insurance.additionalInsured || "—"}
        </p>
        <p className="mt-1 text-[12px]">
          Certificate holder: {pack.insurance.certificateHolder || gc}
        </p>
        <div className="mt-4">
          <H>Bond (threshold ${Number(pack.insurance.bondThreshold || 0).toLocaleString()})</H>
          <Bullets items={pack.insurance.bondNotes} />
        </div>
        <div className="mt-4">
          <H>Safety / site rules that affect price</H>
          <Bullets items={pack.insurance.safety} />
        </div>
      </Page>

      <Page n={6} title="06  —  Work Restrictions / Schedule" {...pageProps}>
        <H>Hours</H>
        <Bullets items={pack.schedule.hours} />
        <div className="mt-4">
          <H>Operations</H>
          <Bullets items={pack.schedule.operations} />
        </div>
        <div className="mt-4">
          <H>Phasing</H>
          <Table
            headers={["Phase", "Nights (est.)", "Work"]}
            rows={pack.schedule.phases.map((ph) => [ph.name, ph.nights, ph.work])}
          />
        </div>
        <div className="mt-4">
          <H>What bidders may ask before bidding</H>
          <Bullets items={pack.schedule.bidderQuestions} />
        </div>
        {pack.schedule.liquidatedDamages ? (
          <p className="mt-4 text-[12px]">
            <strong>Liquidated damages: </strong>
            {pack.schedule.liquidatedDamages}
          </p>
        ) : null}
      </Page>

      <Page n={7} title="07  —  Drawings, Specs & Addenda" {...pageProps}>
        <H>Drawing / sketch notes</H>
        <p className="mb-3 text-[12px] leading-relaxed">{pack.drawings.notes || "Issue a sketch or plan with this package."}</p>
        {pack.drawings.missing ? (
          <p className="mb-4 text-[11px] text-muted">Not attached: {pack.drawings.missing}</p>
        ) : null}
        <H>Specifications</H>
        {pack.specs.filter((s) => s.title || s.detail).length ? (
          <Table
            headers={["Item", "Requirement"]}
            rows={pack.specs.map((s) => [s.title, s.detail])}
          />
        ) : (
          <p className="text-[12px] text-muted">Add product and quality rules.</p>
        )}
        <div className="mt-4">
          <H>Addenda</H>
          {pack.addenda.length ? (
            <Table
              headers={["No.", "Date", "Summary"]}
              rows={pack.addenda.map((a) => [a.number, formatDate(a.date), a.summary])}
            />
          ) : (
            <p className="text-[12px] text-muted">None issued. Record later changes here so bidders price the latest version.</p>
          )}
        </div>
      </Page>
    </div>
  );
}
