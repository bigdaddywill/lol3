import { Field, Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useBinder } from "@/lib/store";
import { useEffect, useState } from "react";
import type { CompanyProfile } from "@/lib/types";

export function CompanyForm() {
  const company = useBinder((s) => s.company);
  const setCompany = useBinder((s) => s.setCompany);
  const [draft, setDraft] = useState<CompanyProfile>(company);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setDraft(company);
  }, [company]);

  function patch<K extends keyof CompanyProfile>(k: K, v: CompanyProfile[K]) {
    setDraft({ ...draft, [k]: v });
    setSaved(false);
  }

  return (
    <form
      className="grid max-w-xl gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        setCompany(draft);
        setSaved(true);
      }}
    >
      <Field label="Company name">
        <Input value={draft.name} onChange={(e) => patch("name", e.target.value)} />
      </Field>
      <Field label="Legal name">
        <Input value={draft.legalName} onChange={(e) => patch("legalName", e.target.value)} />
      </Field>
      <Field label="Street">
        <Input value={draft.address} onChange={(e) => patch("address", e.target.value)} />
      </Field>
      <div className="grid grid-cols-3 gap-2">
        <Field label="City" className="col-span-1">
          <Input value={draft.city} onChange={(e) => patch("city", e.target.value)} />
        </Field>
        <Field label="State">
          <Input value={draft.state} onChange={(e) => patch("state", e.target.value)} />
        </Field>
        <Field label="ZIP">
          <Input value={draft.zip} onChange={(e) => patch("zip", e.target.value)} />
        </Field>
      </div>
      <Field label="Phone">
        <Input value={draft.phone} onChange={(e) => patch("phone", e.target.value)} />
      </Field>
      <Field label="PM email">
        <Input value={draft.email} onChange={(e) => patch("email", e.target.value)} />
      </Field>
      <Field label="Bids email">
        <Input value={draft.bidsEmail} onChange={(e) => patch("bidsEmail", e.target.value)} />
      </Field>
      <div className="flex items-center gap-3 pt-2">
        <Button type="submit">Save company</Button>
        {saved ? <span className="text-sm text-ok">Saved. New packages inherit this.</span> : null}
      </div>
    </form>
  );
}
