import { Upload } from "lucide-react";
import { useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { parsePacketFile } from "@/lib/files";
import { useBinder } from "@/lib/store";

export function ImportJsonButton({ ghost = false }: { ghost?: boolean }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const upsert = useBinder((s) => s.upsert);
  const setCompany = useBinder((s) => s.setCompany);
  const company = useBinder((s) => s.company);
  const [err, setErr] = useState("");

  async function onFile(file: File) {
    setErr("");
    try {
      const text = await file.text();
      const parsed = parsePacketFile(text, company);
      upsert(parsed.pack);
      if (parsed.company?.name) setCompany({ ...company, ...parsed.company });
      void navigate({ to: "/package/$id", params: { id: parsed.pack.id } });
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not read that file.");
    }
  }

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void onFile(file);
        }}
      />
      <Button
        variant={ghost ? "ghost" : "outline"}
        size="sm"
        className={ghost ? "text-paper hover:bg-paper/10" : ""}
        onClick={() => inputRef.current?.click()}
      >
        <Upload />
        Import
      </Button>
      {err ? <span className="text-xs text-danger">{err}</span> : null}
    </>
  );
}