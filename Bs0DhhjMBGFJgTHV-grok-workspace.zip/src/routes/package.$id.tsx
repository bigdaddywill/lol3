import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Check, Copy, Printer, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { DocumentPreview } from "@/components/document-preview";
import { ExportActions } from "@/components/export-actions";
import { PackageEditor, SECTIONS, type SectionId } from "@/components/package-editor";
import { Button } from "@/components/ui/button";
import { completeness } from "@/lib/completeness";
import { useBinder } from "@/lib/store";
import { issuerForPackage } from "@/lib/templates";
import type { BidPackage, PackageStatus } from "@/lib/types";

export const Route = createFileRoute("/package/$id")({ component: EditorPage });

function EditorPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const hydrated = useBinder((s) => s.hydrated);
  const stored = useBinder((s) => s.packages.find((p) => p.id === id));
  const upsert = useBinder((s) => s.upsert);
  const remove = useBinder((s) => s.remove);
  const duplicate = useBinder((s) => s.duplicate);
  const ensureSeed = useBinder((s) => s.ensureSeed);
  const company = useBinder((s) => s.company);
  const [pack, setPack] = useState<BidPackage | null>(null);
  const [section, setSection] = useState<SectionId>("invite");
  const [pane, setPane] = useState<"edit" | "preview">("edit");

  useEffect(() => {
    if (!hydrated) return;
    ensureSeed(id);
  }, [hydrated, id, ensureSeed]);

  useEffect(() => {
    if (stored) setPack(stored);
    else if (hydrated) setPack(null);
  }, [id, stored, hydrated]);

  useEffect(() => {
    if (!pack || pack.id !== id) return;
    const t = window.setTimeout(() => upsert(pack), 350);
    return () => window.clearTimeout(t);
  }, [pack, upsert, id]);

  const view = pack?.id === id ? pack : stored ?? pack;
  const stats = useMemo(() => (view ? completeness(view) : null), [view]);

  if (!hydrated) {
    return <p className="p-8 text-sm text-muted">Loading…</p>;
  }

  if (!view) {
    return (
      <main className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="font-display text-xl font-semibold">Package not found</p>
        <Button className="mt-4" asChild>
          <Link to="/">Back to binder</Link>
        </Button>
      </main>
    );
  }

  return (
    <div className="min-h-dvh bg-bg">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-navy text-paper">
        <div className="flex flex-wrap items-center gap-2 px-3 py-3 sm:px-4">
          <Button variant="ghost" size="sm" className="text-paper hover:bg-paper/10" asChild>
            <Link to="/">
              <ArrowLeft />
              Binder
            </Link>
          </Button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-base font-semibold">
              {view.invitation.projectName || "Untitled package"}
            </p>
            <p className="text-xs text-paper/70">
              {view.trade} · {stats?.pct}% ready · {stats?.done}/{stats?.total} sections
            </p>
          </div>
          <select
            className="h-9 rounded-sm border border-paper/20 bg-navy px-2 text-xs text-paper"
            value={view.status}
            onChange={(e) => setPack({ ...view, status: e.target.value as PackageStatus })}
          >
            <option value="draft">Draft</option>
            <option value="issued">Issued</option>
            <option value="closed">Closed</option>
          </select>
          <Button
            variant="ghost"
            size="sm"
            className="text-paper hover:bg-paper/10"
            onClick={() => {
              const copy = duplicate(view.id);
              if (copy) void navigate({ to: "/package/$id", params: { id: copy.id } });
            }}
          >
            <Copy />
            <span className="hidden sm:inline">Duplicate</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-paper hover:bg-paper/10"
            onClick={() => {
              if (confirm("Delete this package?")) {
                remove(view.id);
                void navigate({ to: "/" });
              }
            }}
          >
            <Trash2 />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-paper hover:bg-paper/10"
            asChild
          >
            <Link to="/print/$id" params={{ id: view.id }}>
              <Printer />
              <span className="hidden sm:inline">Print</span>
            </Link>
          </Button>
          <ExportActions pack={view} company={company} compact />
        </div>
      </header>

      <div className="no-print flex gap-1 border-b border-line bg-surface px-3 py-1 lg:hidden">
        {(["edit", "preview"] as const).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setPane(k)}
            className={`h-10 flex-1 rounded-md text-sm font-medium ${
              pane === k ? "bg-paper text-navy" : "text-muted"
            }`}
          >
            {k === "edit" ? "Edit" : "Preview"}
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <section className={`min-w-0 border-r border-line ${pane === "preview" ? "hidden lg:block" : ""}`}>
          <nav className="no-print flex gap-1 overflow-x-auto border-b border-line bg-surface px-2 py-2">
            {SECTIONS.map((s) => {
              const check = stats?.checks.find((c) =>
                s.id === "invite"
                  ? c.id === "invite"
                  : s.id === "project"
                    ? c.id === "project"
                    : s.id === "contacts"
                      ? c.id === "contacts"
                      : s.id === "scope"
                        ? c.id === "scope"
                        : s.id === "bidform"
                          ? c.id === "bidform"
                          : s.id === "insurance"
                            ? c.id === "insurance"
                            : s.id === "schedule"
                              ? c.id === "schedule"
                              : s.id === "drawings"
                                ? c.id === "drawings" || c.id === "specs"
                                : false,
              );
              const done = s.id === "addenda" ? true : Boolean(check?.done);
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSection(s.id)}
                  className={`flex h-10 shrink-0 items-center gap-1.5 rounded-md px-3 text-xs font-medium ${
                    section === s.id ? "bg-navy text-paper" : "text-muted hover:bg-paper"
                  }`}
                >
                  {done ? <Check className="size-3" /> : null}
                  {s.label}
                </button>
              );
            })}
          </nav>
          {stats && stats.pct < 100 ? (
            <div className="border-b border-line bg-warn/10 px-4 py-2 text-xs text-warn">
              Still open: {stats.checks.filter((c) => !c.done).map((c) => c.label.split(" — ")[0]).join(" · ")}
            </div>
          ) : (
            <div className="border-b border-line bg-ok/10 px-4 py-2 text-xs text-ok">
              All nine required pieces are filled. Print and send.
            </div>
          )}
          <div className="p-4 sm:p-5">
            <PackageEditor pack={view} onChange={setPack} section={section} />
          </div>
        </section>

        <aside
          className={`min-h-[70vh] bg-steel/10 p-3 sm:p-6 ${pane === "edit" ? "hidden lg:block" : ""}`}
        >
          <p className="no-print mb-3 text-center font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-navy/70">
            Live package
          </p>
          <DocumentPreview pack={view} company={issuerForPackage(view, company)} />
        </aside>
      </div>
    </div>
  );
}
