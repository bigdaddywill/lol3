import { createFileRoute, Link } from "@tanstack/react-router";
import { FileStack, Plus, Settings2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ImportJsonButton } from "@/components/import-json";
import { NewPackageDialog } from "@/components/new-package-dialog";
import { completeness } from "@/lib/completeness";
import { useBinder } from "@/lib/store";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrated = useBinder((s) => s.hydrated);
  const packages = useBinder((s) => s.packages);
  const loadSample = useBinder((s) => s.loadSample);
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="no-print border-b border-line bg-navy text-paper">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-sm bg-paper text-navy">
              <FileStack className="size-4" />
            </span>
            <div>
              <p className="font-display text-lg font-semibold tracking-tight">Packet</p>
              <p className="text-xs text-paper/70">Bid packages for general contractors</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="text-paper hover:bg-paper/10" asChild>
              <Link to="/settings">
                <Settings2 />
                <span className="hidden sm:inline">Company</span>
              </Link>
            </Button>
            <ImportJsonButton ghost />
            <Button size="sm" className="bg-paper text-navy hover:bg-paper/90" onClick={() => setOpen(true)}>
              <Plus />
              New package
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="max-w-2xl text-sm leading-relaxed text-muted">
          Fill the job once. Packet writes the invitation, project data, scope, bid form,
          insurance sheet, and night-work rules a sub actually needs to price. Download PDF
          when it’s ready — JSON is the backup you can import on another machine.
        </p>

        {!hydrated ? (
          <p className="mt-10 text-sm text-muted">Loading binders…</p>
        ) : packages.length === 0 ? (
          <div className="mt-10 rounded-xl border border-line bg-surface px-6 py-12 text-center">
            <p className="font-display text-lg font-semibold">No packages yet</p>
            <p className="mx-auto mt-2 max-w-md text-sm text-muted">
              Start from a trade template. Concrete, electrical, HVAC, and the rest already
              know the usual inclusions, exclusions, and COI lines.
            </p>
            <div className="mt-5 flex flex-col items-center gap-2 sm:flex-row sm:justify-center">
              <Button onClick={() => setOpen(true)}>
                <Plus />
                New package
              </Button>
              <Button variant="outline" onClick={() => loadSample()}>
                Load sample dock package
              </Button>
            </div>
          </div>
        ) : (
          <ul className="mt-8 grid gap-3">
            {packages.map((p) => {
              const c = completeness(p);
              return (
                <li key={p.id}>
                  <Link
                    to="/package/$id"
                    params={{ id: p.id }}
                    className="block rounded-xl border border-line bg-paper p-4 shadow-none transition-colors duration-[var(--motion-quick)] hover:border-navy/30"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="font-display text-lg font-semibold tracking-tight text-navy">
                          {p.invitation.projectName || "Untitled package"}
                        </p>
                        <p className="mt-1 text-sm text-muted">
                          {p.trade}
                          {p.invitation.siteId ? ` · ${p.invitation.siteId}` : ""}
                          {p.invitation.bidDue ? ` · bids ${formatDate(p.invitation.bidDue)}` : ""}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <StatusChip status={p.status} />
                        <span className="font-display text-sm tabular-nums text-navy">
                          {c.pct}% ready
                        </span>
                      </div>
                    </div>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface">
                      <div
                        className="h-full bg-stripe"
                        style={{ width: `${c.pct}%` }}
                      />
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </main>
      <NewPackageDialog open={open} onClose={() => setOpen(false)} />
    </div>
  );
}

function StatusChip({ status }: { status: string }) {
  const label = status === "issued" ? "Issued" : status === "closed" ? "Closed" : "Draft";
  return (
    <span className="rounded-full border border-line bg-surface px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-muted">
      {label}
    </span>
  );
}
