import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { CompanyForm } from "@/components/company-form";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  return (
    <div className="min-h-dvh bg-bg">
      <header className="border-b border-line bg-navy px-4 py-4 text-paper">
        <Button variant="ghost" size="sm" className="text-paper hover:bg-paper/10" asChild>
          <Link to="/">
            <ArrowLeft />
            Binder
          </Link>
        </Button>
        <h1 className="mt-3 font-display text-2xl font-semibold tracking-tight">Company defaults</h1>
        <p className="mt-1 max-w-xl text-sm text-paper/70">
          Printed on every invitation. New packages copy your bids email, additional insured, and certificate holder.
        </p>
      </header>
      <main className="px-4 py-8">
        <CompanyForm />
      </main>
    </div>
  );
}
