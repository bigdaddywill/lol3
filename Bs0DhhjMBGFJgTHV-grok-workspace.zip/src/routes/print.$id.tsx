import { createFileRoute, Link } from "@tanstack/react-router";
import { DocumentPreview } from "@/components/document-preview";
import { ExportActions } from "@/components/export-actions";
import { Button } from "@/components/ui/button";
import { useBinder } from "@/lib/store";
import { issuerForPackage } from "@/lib/templates";

export const Route = createFileRoute("/print/$id")({ component: PrintPage });

function PrintPage() {
  const { id } = Route.useParams();
  const pack = useBinder((s) => s.packages.find((p) => p.id === id));
  const company = useBinder((s) => s.company);
  const hydrated = useBinder((s) => s.hydrated);

  if (!hydrated) return <p className="p-8 text-sm">Loading…</p>;
  if (!pack) {
    return (
      <main className="p-8">
        <p>Package not found.</p>
        <Button className="mt-3" asChild>
          <Link to="/">Home</Link>
        </Button>
      </main>
    );
  }

  return (
    <div className="min-h-dvh bg-bg print:bg-white">
      <div className="no-print flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
        <Button variant="outline" asChild>
          <Link to="/package/$id" params={{ id }}>
            Back to editor
          </Link>
        </Button>
        <div className="flex flex-wrap items-center gap-2">
          <ExportActions pack={pack} company={issuerForPackage(pack, company)} />
          <Button variant="outline" onClick={() => window.print()}>
            Print
          </Button>
        </div>
      </div>
      <div className="mx-auto max-w-3xl py-6 print:max-w-none print:py-0">
        <DocumentPreview pack={pack} company={issuerForPackage(pack, company)} />
      </div>
    </div>
  );
}