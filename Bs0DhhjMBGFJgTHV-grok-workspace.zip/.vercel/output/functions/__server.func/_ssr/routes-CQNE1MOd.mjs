import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, o as FileStack, r as Settings2 } from "../_libs/lucide-react.mjs";
import { a as newPackage, i as useBinder, s as formatDate } from "./router-Be4g4EZb.mjs";
import { t as Button } from "./button-BONEEdHX.mjs";
import { n as Input, t as Field } from "./input-DtuSLy9L.mjs";
import { t as completeness } from "./completeness-CczTe6QJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQNE1MOd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TRADES = [
	"Concrete repair",
	"Electrical",
	"HVAC / mechanical",
	"Painting",
	"Roofing",
	"Sitework / paving",
	"General trades"
];
function NewPackageDialog({ open, onClose }) {
	const navigate = useNavigate();
	const company = useBinder((s) => s.company);
	const upsert = useBinder((s) => s.upsert);
	const [trade, setTrade] = (0, import_react.useState)("Concrete repair");
	const [name, setName] = (0, import_react.useState)("");
	const [site, setSite] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [due, setDue] = (0, import_react.useState)("");
	if (!open) return null;
	function create() {
		const p = newPackage(trade, company);
		p.invitation.projectName = name;
		p.invitation.siteId = site;
		p.invitation.address = address;
		p.invitation.bidDue = due;
		if (company.legalName) p.insurance.certificateHolder = [
			company.legalName,
			company.address,
			[
				company.city,
				company.state,
				company.zip
			].filter(Boolean).join(", ")
		].filter(Boolean).join(", ");
		upsert(p);
		onClose();
		navigate({
			to: "/package/$id",
			params: { id: p.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-navy/50",
			"aria-label": "Close",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 w-full max-w-lg rounded-t-xl border border-line bg-bg p-5 shadow-doc sm:rounded-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold tracking-tight",
					children: "New bid package"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Pick a trade. Invitation, scope, bid form, and insurance start from that template."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Trade",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "flex h-11 w-full rounded-sm border border-line bg-paper px-3 text-sm",
								value: trade,
								onChange: (e) => setTrade(e.target.value),
								children: TRADES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Project name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "Store # — dock repairs"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Site / store ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: site,
								onChange: (e) => setSite(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Address",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: address,
								onChange: (e) => setAddress(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Bids due",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: due,
								onChange: (e) => setDue(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: create,
						children: "Create package"
					})]
				})
			]
		})]
	});
}
function Home() {
	const hydrated = useBinder((s) => s.hydrated);
	const packages = useBinder((s) => s.packages);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "no-print border-b border-line bg-navy text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 place-items-center rounded-sm bg-paper text-navy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileStack, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-semibold tracking-tight",
							children: "Packet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-paper/70",
							children: "Bid packages for general contractors"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "text-paper hover:bg-paper/10",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/settings",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Company"
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "bg-paper text-navy hover:bg-paper/90",
							onClick: () => setOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New package"]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-5xl px-4 py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl text-sm leading-relaxed text-muted",
					children: "Fill the job once. Packet writes the invitation, project data, scope, bid form, insurance sheet, and night-work rules a sub actually needs to price."
				}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-sm text-muted",
					children: "Loading binders…"
				}) : packages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 rounded-xl border border-line bg-surface px-6 py-12 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-semibold",
							children: "No packages yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-2 max-w-md text-sm text-muted",
							children: "Start from a trade template. Concrete, electrical, HVAC, and the rest already know the usual inclusions, exclusions, and COI lines."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-5",
							onClick: () => setOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New package"]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-3",
					children: packages.map((p) => {
						const c = completeness(p);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/package/$id",
							params: { id: p.id },
							className: "block rounded-xl border border-line bg-paper p-4 shadow-none transition-colors duration-[var(--motion-quick)] hover:border-navy/30",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg font-semibold tracking-tight text-navy",
									children: p.invitation.projectName || "Untitled package"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										p.trade,
										p.invitation.siteId ? ` · ${p.invitation.siteId}` : "",
										p.invitation.bidDue ? ` · bids ${formatDate(p.invitation.bidDue)}` : ""
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: p.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-display text-sm tabular-nums text-navy",
										children: [c.pct, "% ready"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1.5 overflow-hidden rounded-full bg-surface",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-stripe",
									style: { width: `${c.pct}%` }
								})
							})]
						}) }, p.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewPackageDialog, {
				open,
				onClose: () => setOpen(false)
			})
		]
	});
}
function StatusChip({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full border border-line bg-surface px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-muted",
		children: status === "issued" ? "Issued" : status === "closed" ? "Closed" : "Draft"
	});
}
//#endregion
export { Home as component };
