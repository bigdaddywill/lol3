//#region node_modules/.nitro/vite/services/ssr/assets/completeness-CczTe6QJ.js
function filled(s) {
	return Boolean(s && s.trim());
}
function listFilled(items) {
	return items.some((x) => filled(x));
}
function packageChecks(p) {
	return [
		{
			id: "invite",
			label: "Invitation — name, address, due date, submit-to",
			done: filled(p.invitation.projectName) && filled(p.invitation.address) && filled(p.invitation.bidDue) && filled(p.invitation.submitTo)
		},
		{
			id: "project",
			label: "Project data — work area and access",
			done: filled(p.project.workArea) && filled(p.project.access)
		},
		{
			id: "contacts",
			label: "Contacts — at least one named person with email",
			done: p.contacts.some((c) => filled(c.name) && filled(c.email))
		},
		{
			id: "scope",
			label: "Scope — base work listed",
			done: listFilled(p.scope.baseItems)
		},
		{
			id: "drawings",
			label: "Drawings — note for bidders",
			done: filled(p.drawings.notes)
		},
		{
			id: "specs",
			label: "Specifications — at least one product/quality rule",
			done: p.specs.some((s) => filled(s.title) || filled(s.detail))
		},
		{
			id: "bidform",
			label: "Bid form — line items with quantities",
			done: p.bidForm.lines.some((l) => filled(l.description) && filled(l.qty))
		},
		{
			id: "insurance",
			label: "Insurance — limits and additional insured",
			done: p.insurance.coverages.length > 0 && filled(p.insurance.additionalInsured)
		},
		{
			id: "schedule",
			label: "Schedule — hours or phases",
			done: listFilled(p.schedule.hours) || p.schedule.phases.some((ph) => filled(ph.work))
		}
	];
}
function completeness(p) {
	const checks = packageChecks(p);
	const done = checks.filter((c) => c.done).length;
	return {
		checks,
		done,
		total: checks.length,
		pct: Math.round(done / checks.length * 100)
	};
}
//#endregion
export { completeness as t };
