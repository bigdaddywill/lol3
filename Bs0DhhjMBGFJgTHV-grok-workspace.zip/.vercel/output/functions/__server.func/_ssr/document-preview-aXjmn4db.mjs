import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as formatDate } from "./router-Be4g4EZb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/document-preview-aXjmn4db.js
var import_jsx_runtime = require_jsx_runtime();
function gcName(c) {
	return c.legalName || c.name || "General Contractor";
}
function Page({ n, total, title, company, projectNo, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "doc-page relative mx-auto flex min-h-[10.5in] w-full max-w-[8.5in] flex-col bg-paper text-navy shadow-doc print:min-h-0 print:shadow-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "bg-navy px-6 py-3 text-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[11px] font-semibold uppercase tracking-[0.18em]",
						children: company
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-right font-sans text-[10px] uppercase tracking-wide text-paper/70",
						children: [
							"Subcontractor bid package",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							projectNo || "Project no. pending"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-0.5 w-full bg-stripe" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-6 pt-3 text-[10px] uppercase tracking-wide text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Page ",
					n,
					" of ",
					total
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 px-6 pb-8 pt-3",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-auto border-t border-line bg-surface px-6 py-2 text-center text-[9px] uppercase tracking-wide text-muted",
				children: "Issued for bidding · Quantities are estimated · Field-measure before pour / install"
			})
		]
	});
}
function H({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "mb-3 bg-steel px-3 py-1.5 font-display text-[11px] font-semibold uppercase tracking-[0.14em] text-paper",
		children
	});
}
function KV({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[8.5rem_1fr] gap-x-3 border-b border-line/80 py-1.5 text-[12px] leading-snug",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-semibold text-navy",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-ink",
			children: v || "—"
		})]
	});
}
function Bullets({ items }) {
	const rows = items.filter((x) => x.trim());
	if (!rows.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[12px] text-muted",
		children: "To be issued."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: rows.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-2 text-[12px] leading-snug text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-1.5 shrink-0 rounded-full bg-stripe" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
		}, i))
	});
}
function Table({ headers, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full border-collapse text-left text-[11px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "bg-navy text-paper",
				children: headers.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "px-2 py-1.5 font-display font-semibold uppercase tracking-wide",
					children: h
				}, h))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: i % 2 === 0 ? "bg-surface/80" : "bg-paper",
				children: r.map((c, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "border-b border-line px-2 py-1.5 text-ink",
					children: c || "—"
				}, j))
			}, i)) })]
		})
	});
}
function DocumentPreview({ pack, company }) {
	const gc = gcName(company);
	const inv = pack.invitation;
	const pageProps = {
		company: gc,
		projectNo: inv.projectNo,
		total: 7
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "doc-stack space-y-6 font-serif print:space-y-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 1,
				title: "01  —  Invitation to Bid",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-semibold tracking-tight text-navy",
						children: "Invitation to Bid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-4 text-[12px] text-muted",
						children: [
							"Trade: ",
							pack.trade,
							" · Bid package no. ",
							inv.packageNo || "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 border-l-4 border-stripe bg-surface px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "Project",
								v: inv.projectName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "Site ID",
								v: inv.siteId
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "Address",
								v: inv.address
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "Owner",
								v: `${inv.owner}${inv.occupied ? "  (occupied)" : ""}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "General contractor",
								v: gc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KV, {
								k: "GC project no.",
								v: inv.projectNo
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Bid milestones" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						headers: [
							"Item",
							"Date / time",
							"Notes"
						],
						rows: [
							[
								"Documents issued",
								formatDate(inv.documentsIssued),
								"This package"
							],
							[
								"RFIs due",
								formatDate(inv.rfiDue),
								"Email only"
							],
							[
								"Bids due",
								`${formatDate(inv.bidDue)}  ${inv.bidDueTime}`.trim(),
								"Late bids not opened"
							],
							[
								"Apparent low notified",
								formatDate(inv.awardNotify),
								"Subject to vetting"
							],
							[
								"Work window",
								inv.workWindow,
								""
							]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "How to submit" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-2 text-[12px]",
								children: [
									"Email one PDF to ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: inv.submitTo || "—" }),
									" with subject:",
									" ",
									inv.projectNo || "PROJECT",
									" / ",
									inv.packageNo || "PKG",
									" / [Your Company]."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] leading-relaxed text-ink",
								children: inv.submitNotes
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 2,
				title: "02  —  Project Data & Contacts",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Project data" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						headers: ["Field", "Value"],
						rows: [
							["Store / site ID", inv.siteId],
							["Building status", pack.project.buildingStatus],
							["Work area", pack.project.workArea],
							["Existing conditions", pack.project.existingConditions],
							["Access", pack.project.access],
							["Dumpster / washout", pack.project.dumpster],
							["Permits", pack.project.permits],
							["Prevailing wage", pack.project.prevailingWage],
							["Tax", pack.project.tax]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Contacts — use these, not a personal cell as the only record" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							headers: [
								"Role",
								"Name",
								"Email / phone"
							],
							rows: pack.contacts.map((c) => [
								c.role,
								c.name,
								[c.email, c.phone].filter(Boolean).join("  ·  ")
							])
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Documents in this package" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.documentsList })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 3,
				title: "03  —  Scope of Work",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(H, { children: ["Base bid — package ", inv.packageNo || "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.scope.baseItems }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Included" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.scope.included })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Excluded" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.scope.excluded })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Unit prices — used for adds / deducts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.scope.unitPriceNotes })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 4,
				title: "04  —  Bid Form (required)",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mb-1 font-display text-xl font-semibold text-navy",
						children: ["Bid Form — Package ", inv.packageNo || "—"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-[11px] text-muted",
						children: "Complete every line. Incomplete forms are not evaluated."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 grid gap-2 text-[12px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Subcontractor legal name: ________________________________" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "License no. / classification: ______________________________" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Contact / cell / email: ____________________________________" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Price breakout (USD)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						headers: [
							"Item",
							"Qty",
							"Unit",
							"Unit price",
							"Amount"
						],
						rows: [
							...pack.bidForm.lines.map((l) => [
								l.description,
								l.qty,
								l.unit,
								"$ ________",
								"$ ________"
							]),
							[
								"BASE BID (sum of lines above)",
								"",
								"",
								"",
								"$ ________"
							],
							[
								"Sales tax (if applicable)",
								"",
								"",
								"",
								"$ ________"
							],
							[
								"TOTAL BID",
								"",
								"",
								"",
								"$ ________"
							]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Unit prices for changes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							headers: [
								"Description",
								"Unit",
								"Add",
								"Deduct"
							],
							rows: pack.bidForm.changePrices.map((l) => [
								l.description,
								l.unit,
								"$ ________",
								"$ ________"
							])
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Acknowledgements — initial" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 text-[12px]",
							children: pack.bidForm.acknowledgements.filter(Boolean).map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["____  ", a] }, i))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-[12px]",
						children: "Authorized signature: _______________________________    Date: ______________"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 5,
				title: "05  —  Insurance, Bond & Safety",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Certificate of insurance — minimums" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						headers: [
							"Coverage",
							"Minimum limit",
							"Notes"
						],
						rows: pack.insurance.coverages.map((c) => [
							c.coverage,
							c.limit,
							c.notes
						])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-[12px] leading-relaxed",
						children: ["Additional insureds: ", pack.insurance.additionalInsured || "—"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[12px]",
						children: ["Certificate holder: ", pack.insurance.certificateHolder || gc]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(H, { children: [
							"Bond (threshold $",
							Number(pack.insurance.bondThreshold || 0).toLocaleString(),
							")"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.insurance.bondNotes })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Safety / site rules that affect price" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.insurance.safety })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border border-warn/30 bg-warn/10 px-3 py-2 text-[11px] leading-relaxed text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-[10px] font-semibold uppercase tracking-wide text-warn",
							children: "Payment rule"
						}), "A real GC asks for a COI and maybe a bond letter. Never ask a sub to pay a vendor, buy materials from a “required supplier,” or cash an overpayment check."]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 6,
				title: "06  —  Work Restrictions / Schedule",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Hours" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.schedule.hours }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Operations" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.schedule.operations })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Phasing" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							headers: [
								"Phase",
								"Nights (est.)",
								"Work"
							],
							rows: pack.schedule.phases.map((ph) => [
								ph.name,
								ph.nights,
								ph.work
							])
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "What bidders may ask before bidding" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: pack.schedule.bidderQuestions })]
					}),
					pack.schedule.liquidatedDamages ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-[12px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Liquidated damages: " }), pack.schedule.liquidatedDamages]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				n: 7,
				title: "07  —  Drawings, Specs & Addenda",
				...pageProps,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Drawing / sketch notes" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-[12px] leading-relaxed",
						children: pack.drawings.notes || "Issue a sketch or plan with this package."
					}),
					pack.drawings.missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-4 text-[11px] text-muted",
						children: ["Not attached: ", pack.drawings.missing]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Specifications" }),
					pack.specs.filter((s) => s.title || s.detail).length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						headers: ["Item", "Requirement"],
						rows: pack.specs.map((s) => [s.title, s.detail])
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[12px] text-muted",
						children: "Add product and quality rules."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(H, { children: "Addenda" }), pack.addenda.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							headers: [
								"No.",
								"Date",
								"Summary"
							],
							rows: pack.addenda.map((a) => [
								a.number,
								formatDate(a.date),
								a.summary
							])
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] text-muted",
							children: "None issued. Record later changes here so bidders price the latest version."
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { DocumentPreview as t };
