import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Check, i as Printer, l as ArrowLeft, n as Trash2, s as Copy } from "../_libs/lucide-react.mjs";
import { c as uid, i as useBinder, r as Route$1 } from "./router-Be4g4EZb.mjs";
import { t as Button } from "./button-BONEEdHX.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-DtuSLy9L.mjs";
import { t as completeness } from "./completeness-CczTe6QJ.mjs";
import { t as DocumentPreview } from "./document-preview-aXjmn4db.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/package._id-vIdb3-mN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StringList({ items, onChange, placeholder = "Add a line", multiline = false }) {
	const rows = items.length ? items : [""];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [rows.map((item, i) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(multiline ? Textarea : Input, {
					value: item,
					placeholder,
					onChange: (e) => {
						const next = [...rows];
						next[i] = e.target.value;
						onChange(next);
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					className: "shrink-0 text-muted hover:text-danger",
					onClick: () => onChange(rows.filter((_, j) => j !== i)),
					"aria-label": "Remove line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
				})]
			}, i);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			className: "self-start",
			onClick: () => onChange([...rows, ""]),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add line"]
		})]
	});
}
function keyedList(rows, blank, onChange) {
	return {
		add: () => onChange([...rows, {
			id: uid(),
			...blank()
		}]),
		remove: (id) => onChange(rows.filter((r) => r.id !== id)),
		patch: (id, patch) => onChange(rows.map((r) => r.id === id ? {
			...r,
			...patch
		} : r))
	};
}
var SECTIONS = [
	{
		id: "invite",
		label: "01 Invitation"
	},
	{
		id: "project",
		label: "02 Project"
	},
	{
		id: "contacts",
		label: "03 Contacts"
	},
	{
		id: "scope",
		label: "04 Scope"
	},
	{
		id: "bidform",
		label: "05 Bid form"
	},
	{
		id: "insurance",
		label: "06 Insurance"
	},
	{
		id: "schedule",
		label: "07 Schedule"
	},
	{
		id: "drawings",
		label: "08 Drawings & specs"
	},
	{
		id: "addenda",
		label: "09 Addenda"
	}
];
function PackageEditor({ pack, onChange, section }) {
	const set = (patch) => onChange({
		...pack,
		...patch
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			section === "invite" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Project name",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.projectName,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								projectName: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Site / store ID",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.siteId,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								siteId: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Project number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.projectNo,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								projectNo: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.address,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								address: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Owner",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.owner,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								owner: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Package no.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.packageNo,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								packageNo: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-end gap-2 pb-1 text-sm text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "size-4 accent-navy",
							checked: pack.invitation.occupied,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								occupied: e.target.checked
							} })
						}), "Occupied building"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Documents issued",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: pack.invitation.documentsIssued,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								documentsIssued: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "RFI due",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: pack.invitation.rfiDue,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								rfiDue: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bids due",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: pack.invitation.bidDue,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								bidDue: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bid time",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.bidDueTime,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								bidDueTime: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Award notify",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: pack.invitation.awardNotify,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								awardNotify: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Work window",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.workWindow,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								workWindow: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Submit bids to (email)",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.invitation.submitTo,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								submitTo: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Submit notes",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 4,
							value: pack.invitation.submitNotes,
							onChange: (e) => set({ invitation: {
								...pack.invitation,
								submitNotes: e.target.value
							} })
						})
					})
				]
			}),
			section === "project" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: [
					["buildingStatus", "Building status"],
					["workArea", "Work area / quantities"],
					["existingConditions", "Existing conditions"],
					["access", "Access"],
					["dumpster", "Dumpster / washout"],
					["permits", "Permits"],
					["prevailingWage", "Prevailing wage"],
					["tax", "Tax"]
				].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 2,
						value: pack.project[key],
						onChange: (e) => set({ project: {
							...pack.project,
							[key]: e.target.value
						} })
					})
				}, key))
			}),
			section === "contacts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [pack.contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 rounded-lg border border-line bg-surface p-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: c.role,
								onChange: (e) => set({ contacts: pack.contacts.map((x) => x.id === c.id ? {
									...x,
									role: e.target.value
								} : x) })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: c.name,
								onChange: (e) => set({ contacts: pack.contacts.map((x) => x.id === c.id ? {
									...x,
									name: e.target.value
								} : x) })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: c.email,
								onChange: (e) => set({ contacts: pack.contacts.map((x) => x.id === c.id ? {
									...x,
									email: e.target.value
								} : x) })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Phone",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: c.phone,
								onChange: (e) => set({ contacts: pack.contacts.map((x) => x.id === c.id ? {
									...x,
									phone: e.target.value
								} : x) })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							className: "text-danger sm:col-span-2",
							onClick: () => set({ contacts: pack.contacts.filter((x) => x.id !== c.id) }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Remove contact"]
						})
					]
				}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					className: "self-start",
					onClick: () => set({ contacts: [...pack.contacts, {
						id: uid(),
						role: "",
						name: "",
						email: "",
						phone: "",
						notes: ""
					}] }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add contact"]
				})]
			}),
			section === "scope" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Base work"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						multiline: true,
						items: pack.scope.baseItems,
						onChange: (baseItems) => set({ scope: {
							...pack.scope,
							baseItems
						} })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Included"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.scope.included,
						onChange: (included) => set({ scope: {
							...pack.scope,
							included
						} })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Excluded"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.scope.excluded,
						onChange: (excluded) => set({ scope: {
							...pack.scope,
							excluded
						} })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Unit-price notes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.scope.unitPriceNotes,
						onChange: (unitPriceNotes) => set({ scope: {
							...pack.scope,
							unitPriceNotes
						} })
					})] })
				]
			}),
			section === "bidform" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Quantities you fill. Unit prices stay blank for the sub."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineTable, {
						rows: pack.bidForm.lines,
						onChange: (lines) => set({ bidForm: {
							...pack.bidForm,
							lines
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Change-order unit prices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineTable, {
						rows: pack.bidForm.changePrices,
						onChange: (changePrices) => set({ bidForm: {
							...pack.bidForm,
							changePrices
						} }),
						hideQty: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Acknowledgements"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.bidForm.acknowledgements,
						onChange: (acknowledgements) => set({ bidForm: {
							...pack.bidForm,
							acknowledgements
						} })
					})
				]
			}),
			section === "insurance" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [
					pack.insurance.coverages.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 rounded-lg border border-line bg-surface p-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Coverage",
								className: "sm:col-span-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: c.coverage,
									onChange: (e) => set({ insurance: {
										...pack.insurance,
										coverages: pack.insurance.coverages.map((x) => x.id === c.id ? {
											...x,
											coverage: e.target.value
										} : x)
									} })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Limit",
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: c.limit,
									onChange: (e) => set({ insurance: {
										...pack.insurance,
										coverages: pack.insurance.coverages.map((x) => x.id === c.id ? {
											...x,
											limit: e.target.value
										} : x)
									} })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Notes",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: c.notes,
									onChange: (e) => set({ insurance: {
										...pack.insurance,
										coverages: pack.insurance.coverages.map((x) => x.id === c.id ? {
											...x,
											notes: e.target.value
										} : x)
									} })
								})
							})
						]
					}, c.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Additional insured",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: pack.insurance.additionalInsured,
							onChange: (e) => set({ insurance: {
								...pack.insurance,
								additionalInsured: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Certificate holder",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.insurance.certificateHolder,
							onChange: (e) => set({ insurance: {
								...pack.insurance,
								certificateHolder: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bond threshold (USD)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.insurance.bondThreshold,
							onChange: (e) => set({ insurance: {
								...pack.insurance,
								bondThreshold: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Bond notes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.insurance.bondNotes,
						onChange: (bondNotes) => set({ insurance: {
							...pack.insurance,
							bondNotes
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Safety"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.insurance.safety,
						onChange: (safety) => set({ insurance: {
							...pack.insurance,
							safety
						} })
					})
				]
			}),
			section === "schedule" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Hours"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.schedule.hours,
						onChange: (hours) => set({ schedule: {
							...pack.schedule,
							hours
						} })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Operations"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.schedule.operations,
						onChange: (operations) => set({ schedule: {
							...pack.schedule,
							operations
						} })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
							children: "Phases"
						}),
						pack.schedule.phases.map((ph) => {
							const k = keyedList(pack.schedule.phases, () => ({
								name: "",
								nights: "",
								work: ""
							}), (phases) => set({ schedule: {
								...pack.schedule,
								phases
							} }));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 grid gap-2 sm:grid-cols-[4rem_5rem_1fr_auto]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: ph.name,
										placeholder: "A",
										onChange: (e) => k.patch(ph.id, { name: e.target.value })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: ph.nights,
										placeholder: "Nights",
										onChange: (e) => k.patch(ph.id, { nights: e.target.value })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: ph.work,
										placeholder: "Work",
										onChange: (e) => k.patch(ph.id, { work: e.target.value })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon",
										onClick: () => k.remove(ph.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
									})
								]
							}, ph.id);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => set({ schedule: {
								...pack.schedule,
								phases: [...pack.schedule.phases, {
									id: uid(),
									name: "",
									nights: "",
									work: ""
								}]
							} }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add phase"]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Liquidated damages",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: pack.schedule.liquidatedDamages,
							onChange: (e) => set({ schedule: {
								...pack.schedule,
								liquidatedDamages: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
						children: "Bidder questions you will answer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StringList, {
						items: pack.schedule.bidderQuestions,
						onChange: (bidderQuestions) => set({ schedule: {
							...pack.schedule,
							bidderQuestions
						} })
					})] })
				]
			}),
			section === "drawings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Drawing / sketch notes for bidders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 5,
							value: pack.drawings.notes,
							onChange: (e) => set({ drawings: {
								...pack.drawings,
								notes: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What is not attached (tell them to ask)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: pack.drawings.missing,
							onChange: (e) => set({ drawings: {
								...pack.drawings,
								missing: e.target.value
							} })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: "Specs"
					}),
					pack.specs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[10rem_1fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Title",
								value: s.title,
								onChange: (e) => set({ specs: pack.specs.map((x) => x.id === s.id ? {
									...x,
									title: e.target.value
								} : x) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Requirement",
								value: s.detail,
								onChange: (e) => set({ specs: pack.specs.map((x) => x.id === s.id ? {
									...x,
									detail: e.target.value
								} : x) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								onClick: () => set({ specs: pack.specs.filter((x) => x.id !== s.id) }),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					}, s.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						className: "self-start",
						onClick: () => set({ specs: [...pack.specs, {
							id: uid(),
							title: "",
							detail: ""
						}] }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add spec"]
					})
				]
			}),
			section === "addenda" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "When the drawings or due date change, add a line. Bidders must price the latest addendum."
					}),
					pack.addenda.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[5rem_9rem_1fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "No.",
								value: a.number,
								onChange: (e) => set({ addenda: pack.addenda.map((x) => x.id === a.id ? {
									...x,
									number: e.target.value
								} : x) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: a.date,
								onChange: (e) => set({ addenda: pack.addenda.map((x) => x.id === a.id ? {
									...x,
									date: e.target.value
								} : x) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Summary",
								value: a.summary,
								onChange: (e) => set({ addenda: pack.addenda.map((x) => x.id === a.id ? {
									...x,
									summary: e.target.value
								} : x) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								onClick: () => set({ addenda: pack.addenda.filter((x) => x.id !== a.id) }),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					}, a.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						className: "self-start",
						onClick: () => set({ addenda: [...pack.addenda, {
							id: uid(),
							number: String(pack.addenda.length + 1),
							date: "",
							summary: ""
						}] }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add addendum"]
					})
				]
			})
		]
	});
}
function LineTable({ rows, onChange, hideQty }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [rows.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_4.5rem_4rem_auto] gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Description",
					value: l.description,
					onChange: (e) => onChange(rows.map((x) => x.id === l.id ? {
						...x,
						description: e.target.value
					} : x))
				}),
				hideQty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Qty",
					value: l.qty,
					onChange: (e) => onChange(rows.map((x) => x.id === l.id ? {
						...x,
						qty: e.target.value
					} : x))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Unit",
					value: l.unit,
					onChange: (e) => onChange(rows.map((x) => x.id === l.id ? {
						...x,
						unit: e.target.value
					} : x))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					onClick: () => onChange(rows.filter((x) => x.id !== l.id)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
				})
			]
		}, l.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			className: "self-start",
			onClick: () => onChange([...rows, {
				id: uid(),
				description: "",
				qty: "",
				unit: ""
			}]),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add line"]
		})]
	});
}
function EditorPage() {
	const { id } = Route$1.useParams();
	const navigate = useNavigate();
	const hydrated = useBinder((s) => s.hydrated);
	const stored = useBinder((s) => s.packages.find((p) => p.id === id));
	const upsert = useBinder((s) => s.upsert);
	const remove = useBinder((s) => s.remove);
	const duplicate = useBinder((s) => s.duplicate);
	const company = useBinder((s) => s.company);
	const [pack, setPack] = (0, import_react.useState)(null);
	const [section, setSection] = (0, import_react.useState)("invite");
	const [pane, setPane] = (0, import_react.useState)("edit");
	(0, import_react.useEffect)(() => {
		if (stored) setPack(stored);
	}, [stored]);
	(0, import_react.useEffect)(() => {
		if (!pack) return;
		const t = window.setTimeout(() => upsert(pack), 350);
		return () => window.clearTimeout(t);
	}, [pack, upsert]);
	const stats = (0, import_react.useMemo)(() => pack ? completeness(pack) : null, [pack]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8 text-sm text-muted",
		children: "Loading…"
	});
	if (!pack) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-semibold",
			children: "Package not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Back to binder"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "no-print sticky top-0 z-20 border-b border-line bg-navy text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 px-3 py-3 sm:px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "text-paper hover:bg-paper/10",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), "Binder"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-base font-semibold",
								children: pack.invitation.projectName || "Untitled package"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-paper/70",
								children: [
									pack.trade,
									" · ",
									stats?.pct,
									"% ready · ",
									stats?.done,
									"/",
									stats?.total,
									" sections"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-9 rounded-sm border border-paper/20 bg-navy px-2 text-xs text-paper",
							value: pack.status,
							onChange: (e) => setPack({
								...pack,
								status: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "draft",
									children: "Draft"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "issued",
									children: "Issued"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "closed",
									children: "Closed"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							size: "sm",
							className: "text-paper hover:bg-paper/10",
							onClick: () => {
								const copy = duplicate(pack.id);
								if (copy) navigate({
									to: "/package/$id",
									params: { id: copy.id }
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Duplicate"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "text-paper hover:bg-paper/10",
							onClick: () => {
								if (confirm("Delete this package?")) {
									remove(pack.id);
									navigate({ to: "/" });
								}
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "bg-paper text-navy hover:bg-paper/90",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/print/$id",
								params: { id: pack.id },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Print"]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print flex gap-1 border-b border-line bg-surface px-3 py-1 lg:hidden",
				children: ["edit", "preview"].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPane(k),
					className: `h-10 flex-1 rounded-md text-sm font-medium ${pane === k ? "bg-paper text-navy" : "text-muted"}`,
					children: k === "edit" ? "Edit" : "Preview"
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: `min-w-0 border-r border-line ${pane === "preview" ? "hidden lg:block" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "no-print flex gap-1 overflow-x-auto border-b border-line bg-surface px-2 py-2",
							children: SECTIONS.map((s) => {
								const check = stats?.checks.find((c) => s.id === "invite" ? c.id === "invite" : s.id === "project" ? c.id === "project" : s.id === "contacts" ? c.id === "contacts" : s.id === "scope" ? c.id === "scope" : s.id === "bidform" ? c.id === "bidform" : s.id === "insurance" ? c.id === "insurance" : s.id === "schedule" ? c.id === "schedule" : s.id === "drawings" ? c.id === "drawings" || c.id === "specs" : false);
								const done = s.id === "addenda" ? true : Boolean(check?.done);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSection(s.id),
									className: `flex h-10 shrink-0 items-center gap-1.5 rounded-md px-3 text-xs font-medium ${section === s.id ? "bg-navy text-paper" : "text-muted hover:bg-paper"}`,
									children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : null, s.label]
								}, s.id);
							})
						}),
						stats && stats.pct < 100 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-line bg-warn/10 px-4 py-2 text-xs text-warn",
							children: ["Still open: ", stats.checks.filter((c) => !c.done).map((c) => c.label.split(" — ")[0]).join(" · ")]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-b border-line bg-ok/10 px-4 py-2 text-xs text-ok",
							children: "All nine required pieces are filled. Print and send."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-4 sm:p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageEditor, {
								pack,
								onChange: setPack,
								section
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: `min-h-[70vh] bg-steel/10 p-3 sm:p-6 ${pane === "edit" ? "hidden lg:block" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "no-print mb-3 text-center font-display text-[11px] font-semibold uppercase tracking-[0.18em] text-navy/70",
						children: "Live package"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentPreview, {
						pack,
						company
					})]
				})]
			})
		]
	});
}
//#endregion
export { EditorPage as component };
