import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as ArrowLeft } from "../_libs/lucide-react.mjs";
import { i as useBinder } from "./router-Be4g4EZb.mjs";
import { t as Button } from "./button-BONEEdHX.mjs";
import { n as Input, t as Field } from "./input-DtuSLy9L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BbvttvYw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CompanyForm() {
	const company = useBinder((s) => s.company);
	const setCompany = useBinder((s) => s.setCompany);
	const [draft, setDraft] = (0, import_react.useState)(company);
	const [saved, setSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDraft(company);
	}, [company]);
	function patch(k, v) {
		setDraft({
			...draft,
			[k]: v
		});
		setSaved(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid max-w-xl gap-3",
		onSubmit: (e) => {
			e.preventDefault();
			setCompany(draft);
			setSaved(true);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Company name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.name,
					onChange: (e) => patch("name", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Legal name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.legalName,
					onChange: (e) => patch("legalName", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Street",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.address,
					onChange: (e) => patch("address", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "City",
						className: "col-span-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.city,
							onChange: (e) => patch("city", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "State",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.state,
							onChange: (e) => patch("state", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ZIP",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.zip,
							onChange: (e) => patch("zip", e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.phone,
					onChange: (e) => patch("phone", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "PM email",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.email,
					onChange: (e) => patch("email", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Bids email",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.bidsEmail,
					onChange: (e) => patch("bidsEmail", e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Save company"
				}), saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-ok",
					children: "Saved. New packages inherit this."
				}) : null]
			})
		]
	});
}
function SettingsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b border-line bg-navy px-4 py-4 text-paper",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					className: "text-paper hover:bg-paper/10",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), "Binder"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-2xl font-semibold tracking-tight",
					children: "Company defaults"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm text-paper/70",
					children: "Printed on every invitation. New packages copy your bids email, additional insured, and certificate holder."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "px-4 py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyForm, {})
		})]
	});
}
//#endregion
export { SettingsPage as component };
