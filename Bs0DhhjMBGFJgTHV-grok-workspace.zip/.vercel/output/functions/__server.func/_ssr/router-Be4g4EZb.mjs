import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Be4g4EZb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function todayISO() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function formatDate(iso) {
	if (!iso) return "—";
	const d = /* @__PURE__ */ new Date(iso + (iso.length <= 10 ? "T12:00:00" : ""));
	if (Number.isNaN(d.getTime())) return iso;
	return d.toLocaleDateString("en-US", {
		weekday: "short",
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
function basePackage(trade, company) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const gc = company.legalName || company.name || "[GC company]";
	const bids = company.bidsEmail || company.email || "bids@your-gc.example";
	return {
		id: uid(),
		createdAt: now,
		updatedAt: now,
		status: "draft",
		trade,
		invitation: {
			projectName: "",
			siteId: "",
			address: "",
			owner: "",
			occupied: true,
			packageNo: "03A",
			projectNo: "",
			documentsIssued: todayISO(),
			rfiDue: "",
			bidDue: "",
			bidDueTime: "2:00 PM",
			awardNotify: "",
			workWindow: "",
			submitTo: bids,
			submitNotes: "Email one PDF. Include signed bid form, license, current COI, and bondability letter if your total exceeds the threshold on the insurance page. Unit prices are mandatory. A lump-sum-only quote will be marked incomplete. Do not text numbers to the superintendent."
		},
		project: {
			buildingStatus: "Occupied — work around live operations",
			workArea: "",
			existingConditions: "",
			access: "",
			dumpster: "GC provides dumpster. Sub loads it. Overages on the bid form.",
			permits: "GC holds building permit. Sub pulls trade permits if required.",
			prevailingWage: "No. Private owner.",
			tax: "Show sales tax separately on the bid form."
		},
		contacts: [
			{
				id: uid(),
				role: "Project manager",
				name: "",
				email: company.email,
				phone: company.phone,
				notes: ""
			},
			{
				id: uid(),
				role: "Superintendent",
				name: "",
				email: "",
				phone: "",
				notes: ""
			},
			{
				id: uid(),
				role: "Estimator / bids",
				name: "Bids desk",
				email: bids,
				phone: "",
				notes: ""
			}
		],
		documentsList: [
			"01 Invitation to Bid",
			"02 Project Data & Contacts",
			"03 Scope of Work",
			"04 Bid Form (required)",
			"05 Insurance, Bond & Safety Minimums",
			"06 Work Restrictions / Schedule",
			"07 Sketch / drawing notes"
		],
		scope: {
			baseItems: [""],
			included: [""],
			excluded: [""],
			unitPriceNotes: [""]
		},
		drawings: {
			notes: "Field-measure all quantities. Discrepancies over 10% are an RFI, not a guess.",
			missing: ""
		},
		specs: [{
			id: uid(),
			title: "",
			detail: ""
		}],
		bidForm: {
			lines: [{
				id: uid(),
				description: "Mobilization / protection",
				qty: "1",
				unit: "LS"
			}],
			changePrices: [{
				id: uid(),
				description: "Crew standby, owner delay",
				qty: "",
				unit: "HR"
			}],
			acknowledgements: [
				"I received Invitation, Scope, Bid Form, Insurance sheet, Work Restrictions, and drawings.",
				"I can staff the hours on the schedule page.",
				"I can furnish the insurance limits within 5 days of notice of award.",
				"If my bid is over the bond threshold I attach a surety letter of bondability.",
				"This bid is firm for 30 days. No deposit or off-contract payment is requested."
			]
		},
		insurance: {
			coverages: [
				{
					id: uid(),
					coverage: "Commercial General Liability",
					limit: "$1,000,000 occ / $2,000,000 agg",
					notes: "Per project aggregate"
				},
				{
					id: uid(),
					coverage: "Auto liability",
					limit: "$1,000,000",
					notes: "Any auto"
				},
				{
					id: uid(),
					coverage: "Workers’ compensation",
					limit: "Statutory",
					notes: "Include waiver of subrogation"
				},
				{
					id: uid(),
					coverage: "Employer’s liability",
					limit: "$1,000,000",
					notes: ""
				},
				{
					id: uid(),
					coverage: "Umbrella / excess",
					limit: "$1,000,000",
					notes: "Required if base bid ≥ bond threshold"
				}
			],
			additionalInsured: `${gc} and the Owner, primary and non-contributory.`,
			certificateHolder: gc,
			bondThreshold: "75000",
			bondNotes: [
				"Bids at or over the threshold: attach a letter from a surety admitted in the project state.",
				"If awarded over the threshold, a performance and payment bond equal to 100% of the subcontract may be required within 10 days.",
				"Bond premium, if required, is a line-item reimbursable at cost with backup.",
				"“Bonded” means a surety will stand behind the job. It does not mean licensed or insured."
			],
			safety: [
				"Hard hats, hi-vis, and eye protection on site.",
				"Report any injury, property strike, or store complaint to the superintendent before the shift ends.",
				"Your EMR and a 1-page safety sheet may be requested before award."
			]
		},
		schedule: {
			hours: [""],
			operations: [""],
			phases: [{
				id: uid(),
				name: "A",
				nights: "",
				work: ""
			}],
			bidderQuestions: ["May I walk the site after hours if I check in with the night manager?", "Who owns dumpster overages?"],
			liquidatedDamages: ""
		},
		addenda: []
	};
}
var TRADE_FILL = {
	"Concrete repair": (p) => {
		p.invitation.packageNo = "03A";
		p.invitation.workWindow = "Nights 10:00 PM – 5:00 AM";
		p.project.workArea = "Apron SF, joint LF, and column-base count — fill from takeoff.";
		p.project.existingConditions = "Existing dock / apron slab. Confirm thickness in the field.";
		p.project.access = "Service yard only. No customer-lot staging.";
		p.scope.baseItems = [
			"Mobilize for night work. Furnish labor, equipment, materials, haul-off, and protection.",
			"Sawcut, remove, and replace failed panels as hatched on the drawing. Match existing elevation ±1/8\".",
			"Route and clean existing control/construction joints and install specified joint filler, recessed 1/8\".",
			"Repair spalled column bases: chip to sound concrete, clean steel, bonding slurry, form and place repair mortar to original profile.",
			"Protect doors, levelers, seals, and the building. No dust inside occupied space.",
			"Place, finish, cure, and saw new joints to match existing pattern.",
			"Daily cleanup. Release required docks each morning unless a written shutdown was issued."
		];
		p.scope.included = [
			"Night-shift premium, lights, and a spotter when trucks are backing.",
			"Traffic cones and lighted barricades at the work face.",
			"Concrete, rebar, dowels, epoxy gel, joint filler, repair mortar, and bond breaker."
		];
		p.scope.excluded = [
			"Dock leveler replacement or pit steel.",
			"Overhead doors, seals, bumpers, or striping.",
			"Underground plumbing beyond drains shown.",
			"Hazardous material abatement — stop and call the superintendent."
		];
		p.scope.unitPriceNotes = [
			"Extra / credit panel replacement per SF.",
			"Extra / credit joint filler per LF.",
			"Extra column-base repair each.",
			"Standby hourly rate if the owner holds the area through no fault of the sub."
		];
		p.specs = [
			{
				id: uid(),
				title: "Concrete mix",
				detail: "Match existing PSI unless noted. Confirm with superintendent before first pour."
			},
			{
				id: uid(),
				title: "Joint filler",
				detail: "Two-component polyurea, Shore A 80–90, or equal approved in writing."
			},
			{
				id: uid(),
				title: "Repair mortar",
				detail: "Polymer-modified, applied to sound substrate with manufacturer bonding slurry."
			},
			{
				id: uid(),
				title: "Finish / cure",
				detail: "Match adjacent surface. Curing compound compatible with joint filler."
			}
		];
		p.bidForm.lines = [
			{
				id: uid(),
				description: "Mobilization / night setup / protection",
				qty: "1",
				unit: "LS"
			},
			{
				id: uid(),
				description: "Apron panel remove & replace",
				qty: "",
				unit: "SF"
			},
			{
				id: uid(),
				description: "Joint route / clean / fill",
				qty: "",
				unit: "LF"
			},
			{
				id: uid(),
				description: "Column-base spall repairs",
				qty: "",
				unit: "EA"
			},
			{
				id: uid(),
				description: "Haul-off / dump fees beyond GC box",
				qty: "1",
				unit: "LS"
			}
		];
		p.bidForm.changePrices = [
			{
				id: uid(),
				description: "Additional panel replacement",
				qty: "",
				unit: "SF"
			},
			{
				id: uid(),
				description: "Additional joint filler",
				qty: "",
				unit: "LF"
			},
			{
				id: uid(),
				description: "Additional column-base repair",
				qty: "",
				unit: "EA"
			},
			{
				id: uid(),
				description: "Crew standby after shift start, owner delay",
				qty: "",
				unit: "HR"
			}
		];
		p.schedule.hours = ["Work face opens 10:00 PM. Tools down, yard swept, docks released by 5:00 AM.", "No arrival staging in customer parking before 9:30 PM."];
		p.schedule.operations = [
			"Named docks stay live every night unless a shutdown ticket is issued that afternoon.",
			"One spotter from the sub crew is required whenever a mixer or saw is in the drive lane.",
			"No radios pointed at the building. No idling under the canopy after 10:30 PM."
		];
		p.schedule.liquidatedDamages = "$500 per dock per hour if not released at 5:00 AM, capped at $2,500/night.";
		p.insurance.safety.unshift("Sawcutting: wet cut only. Slurry contained. No slurry in the drain.");
	},
	Electrical: (p) => {
		p.invitation.packageNo = "26A";
		p.scope.baseItems = [
			"Provide complete electrical for the areas shown, including demo of abandoned circuits.",
			"New branch circuits, devices, and lighting as scheduled.",
			"Coordinate shutdowns with the superintendent 48 hours in advance.",
			"Label panels. Test and certify before turnover."
		];
		p.scope.excluded = [
			"Utility company charges.",
			"Fire alarm unless shown.",
			"Low-voltage data cabling unless listed."
		];
		p.specs = [{
			id: uid(),
			title: "Code",
			detail: "NEC current cycle adopted by the AHJ."
		}, {
			id: uid(),
			title: "Gear",
			detail: "Match existing manufacturer where adding to a panel."
		}];
		p.bidForm.lines = [
			{
				id: uid(),
				description: "Mobilization",
				qty: "1",
				unit: "LS"
			},
			{
				id: uid(),
				description: "Demo / safe-off",
				qty: "1",
				unit: "LS"
			},
			{
				id: uid(),
				description: "New devices / lighting",
				qty: "",
				unit: "LS"
			}
		];
	},
	"HVAC / mechanical": (p) => {
		p.invitation.packageNo = "23A";
		p.scope.baseItems = [
			"Remove and replace equipment shown. Protect occupied space from dust and condensate.",
			"Reconnect existing piping, power, and controls unless noted as new.",
			"Startup, test, and balance as specified."
		];
		p.scope.excluded = ["Structural steel for new pads unless shown.", "Electrical feeder upgrades by others."];
		p.specs = [{
			id: uid(),
			title: "Refrigerant",
			detail: "Recover per EPA. No venting."
		}, {
			id: uid(),
			title: "Warranty",
			detail: "One year labor, manufacturer parts."
		}];
		p.bidForm.lines = [
			{
				id: uid(),
				description: "Mobilization / protection",
				qty: "1",
				unit: "LS"
			},
			{
				id: uid(),
				description: "Equipment set / reconnect",
				qty: "1",
				unit: "LS"
			},
			{
				id: uid(),
				description: "Startup / TAB",
				qty: "1",
				unit: "LS"
			}
		];
	},
	Painting: (p) => {
		p.invitation.packageNo = "09A";
		p.scope.baseItems = ["Prep, prime, and paint surfaces scheduled. Protect floors, fixtures, and merchandise.", "Occupied-area work after hours unless noted."];
		p.scope.excluded = ["Wallcovering.", "High-performance floor coatings unless listed."];
		p.specs = [{
			id: uid(),
			title: "Products",
			detail: "Owner-approved system. Submit product data with the bid if substituting."
		}];
		p.bidForm.lines = [{
			id: uid(),
			description: "Prep / protection",
			qty: "1",
			unit: "LS"
		}, {
			id: uid(),
			description: "Paint scheduled surfaces",
			qty: "",
			unit: "SF"
		}];
	},
	Roofing: (p) => {
		p.invitation.packageNo = "07A";
		p.invitation.workWindow = "Daytime, weather permitting. No work over occupied sales floor without a written plan.";
		p.scope.baseItems = ["Tear off to the deck in the areas shown. Install specified membrane, flashings, and accessories.", "Daily watertight — no open roof overnight."];
		p.scope.excluded = ["HVAC disconnect/reconnect by mechanical.", "Interior damage from pre-existing leaks."];
		p.specs = [{
			id: uid(),
			title: "System",
			detail: "Manufacturer 20-year NDL or equal. Letter of intent with bid."
		}];
		p.bidForm.lines = [{
			id: uid(),
			description: "Tear-off / haul",
			qty: "",
			unit: "SF"
		}, {
			id: uid(),
			description: "New membrane / flashings",
			qty: "",
			unit: "SF"
		}];
	},
	"Sitework / paving": (p) => {
		p.invitation.packageNo = "31A";
		p.scope.baseItems = ["Sawcut, remove, and replace pavement in the hatched areas. Match existing grades for drainage.", "Stripe to match existing unless a restripe plan is issued."];
		p.scope.excluded = ["Underground utilities not shown.", "Landscape restoration beyond disturbed edge."];
		p.specs = [{
			id: uid(),
			title: "Asphalt",
			detail: "Mix per local DOT equivalent. Compaction tests by GC."
		}];
		p.bidForm.lines = [
			{
				id: uid(),
				description: "Demo / haul",
				qty: "",
				unit: "SF"
			},
			{
				id: uid(),
				description: "New paving",
				qty: "",
				unit: "SF"
			},
			{
				id: uid(),
				description: "Striping",
				qty: "1",
				unit: "LS"
			}
		];
	},
	"General trades": (p) => {
		p.invitation.packageNo = "01A";
		p.scope.baseItems = ["Perform the work described in this package complete, including protection, cleanup, and punch."];
		p.scope.excluded = ["Work shown on other trade packages."];
	}
};
function newPackage(trade, company) {
	const p = basePackage(trade, company);
	TRADE_FILL[trade](p);
	return p;
}
var SAMPLE_ID = "sample-atlas-1847";
function samplePackage() {
	const p = newPackage("Concrete repair", {
		name: "Redrock Field Services",
		legalName: "Redrock Field Services, LLC",
		address: "410 W 300 S, Ste 220",
		city: "Salt Lake City",
		state: "UT",
		zip: "84101",
		phone: "801-555-0144",
		email: "druiz@redrockfield.example",
		bidsEmail: "bids@redrockfield.example",
		website: ""
	});
	p.id = SAMPLE_ID;
	p.status = "issued";
	p.invitation.projectName = "Atlas Fresh #1847 — Receiving Dock & Apron Repairs";
	p.invitation.siteId = "Atlas Fresh #1847";
	p.invitation.address = "8821 W Pioneer Rd, West Jordan, UT 84088";
	p.invitation.owner = "Atlas Fresh Markets, Inc.";
	p.invitation.projectNo = "RFS-26-441";
	p.invitation.packageNo = "03A";
	p.invitation.rfiDue = "2026-09-28";
	p.invitation.bidDue = "2026-10-02";
	p.invitation.bidDueTime = "2:00 PM MT";
	p.invitation.awardNotify = "2026-10-03";
	p.invitation.workWindow = "Oct 19 – Nov 8, 2026 · 10:00 PM – 5:00 AM";
	p.project.buildingStatus = "Occupied grocery — receiving dock remains live";
	p.project.workArea = "11,800 SF apron + 420 LF joints + 7 column bases";
	p.project.existingConditions = "Existing 6\" unreinforced / lightly reinforced dock slab, ~2009";
	p.project.access = "West receiving yard only. No customer parking lot staging.";
	p.contacts = [
		{
			id: uid(),
			role: "Project manager",
			name: "Dana Ruiz",
			email: "druiz@redrockfield.example",
			phone: "801-555-0144",
			notes: ""
		},
		{
			id: uid(),
			role: "Superintendent",
			name: "Cole Maddox",
			email: "cmaddox@redrockfield.example",
			phone: "801-555-0192",
			notes: ""
		},
		{
			id: uid(),
			role: "Estimator / bids",
			name: "Bids desk",
			email: "bids@redrockfield.example",
			phone: "",
			notes: ""
		},
		{
			id: uid(),
			role: "Owner facilities",
			name: "Atlas Fresh — Store Planning",
			email: "facilities@atlasfresh.example",
			phone: "",
			notes: ""
		}
	];
	p.bidForm.lines = [
		{
			id: uid(),
			description: "Mobilization / night setup / protection",
			qty: "1",
			unit: "LS"
		},
		{
			id: uid(),
			description: "Apron panel remove & replace",
			qty: "4,250",
			unit: "SF"
		},
		{
			id: uid(),
			description: "Joint route / clean / polyurea fill",
			qty: "420",
			unit: "LF"
		},
		{
			id: uid(),
			description: "Column-base spall repairs",
			qty: "7",
			unit: "EA"
		},
		{
			id: uid(),
			description: "Dock 5 drain re-pitch",
			qty: "1",
			unit: "LS"
		},
		{
			id: uid(),
			description: "Haul-off / dump fees beyond GC box",
			qty: "1",
			unit: "LS"
		}
	];
	p.drawings.notes = "Joints: existing grid, 420 LF to route and fill. Hatched panels at Docks 3–6 = remove & replace (4,250 SF). Scale is diagrammatic — field-measure.";
	p.drawings.missing = "Full civil CAD and spec section 03 01 30 issue with the file link on a live job.";
	p.schedule.phases = [
		{
			id: uid(),
			name: "A",
			nights: "2",
			work: "Joints at Docks 1–2 (live docks — small tools only)"
		},
		{
			id: uid(),
			name: "B",
			nights: "4",
			work: "Remove/replace apron panels Docks 3–4"
		},
		{
			id: uid(),
			name: "C",
			nights: "4",
			work: "Remove/replace apron panels Docks 5–6 + drain re-pitch"
		},
		{
			id: uid(),
			name: "D",
			nights: "2",
			work: "Column bases + punch / joint filler at new saw cuts"
		}
	];
	p.insurance.certificateHolder = "Redrock Field Services, 410 W 300 S, Ste 220, Salt Lake City, UT 84101";
	p.insurance.additionalInsured = "Redrock Field Services, LLC and Atlas Fresh Markets, Inc. Primary and non-contributory. Waiver of subrogation on GL, auto, and workers’ comp.";
	p.createdAt = "2026-09-17T15:00:00.000Z";
	p.updatedAt = "2026-09-17T15:00:00.000Z";
	p.invitation.documentsIssued = "2026-09-17";
	p.contacts.forEach((c, i) => {
		c.id = `s-c-${i}`;
	});
	p.bidForm.lines.forEach((l, i) => {
		l.id = `s-l-${i}`;
	});
	p.bidForm.changePrices.forEach((l, i) => {
		l.id = `s-u-${i}`;
	});
	p.specs.forEach((s, i) => {
		s.id = `s-sp-${i}`;
	});
	p.insurance.coverages.forEach((c, i) => {
		c.id = `s-ins-${i}`;
	});
	p.schedule.phases.forEach((ph, i) => {
		ph.id = `s-ph-${i}`;
	});
	return p;
}
var KEY = "packet.binder.v1";
function persistSlice(s) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			company: s.company,
			packages: s.packages
		}));
	} catch {}
}
var useBinder = create()((set, get) => ({
	hydrated: true,
	company: {
		name: "Redrock Field Services",
		legalName: "Redrock Field Services, LLC",
		address: "410 W 300 S, Ste 220",
		city: "Salt Lake City",
		state: "UT",
		zip: "84101",
		phone: "801-555-0144",
		email: "druiz@redrockfield.example",
		bidsEmail: "bids@redrockfield.example",
		website: ""
	},
	packages: [samplePackage()],
	setHydrated: () => set({ hydrated: true }),
	setCompany: (company) => {
		set({ company });
		persistSlice(get());
	},
	upsert: (p) => {
		const rest = get().packages.filter((x) => x.id !== p.id);
		set({ packages: [{
			...p,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...rest] });
		persistSlice(get());
	},
	remove: (id) => {
		set({ packages: get().packages.filter((p) => p.id !== id) });
		persistSlice(get());
	},
	duplicate: (id) => {
		const src = get().packages.find((p) => p.id === id);
		if (!src) return null;
		const copy = {
			...structuredClone(src),
			id: crypto.randomUUID(),
			status: "draft",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			invitation: {
				...src.invitation,
				projectName: src.invitation.projectName ? `${src.invitation.projectName} (copy)` : "Untitled copy",
				projectNo: ""
			}
		};
		set({ packages: [copy, ...get().packages] });
		persistSlice(get());
		return copy;
	},
	hydrateFromStorage: () => {
		if (typeof window === "undefined") return;
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed.packages) && parsed.packages.length > 0) {
					set({
						company: parsed.company ? {
							...get().company,
							...parsed.company
						} : get().company,
						packages: parsed.packages,
						hydrated: true
					});
					return;
				}
			}
		} catch {}
		set({ hydrated: true });
		persistSlice(get());
	}
}));
function BinderHydrate() {
	(0, import_react.useEffect)(() => {
		useBinder.getState().hydrateFromStorage();
	}, []);
	return null;
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-rrPfqIF_.css";
var APP_NAME = "Packet";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#1B2A4A"
			},
			{
				name: "description",
				content: "Build subcontractor bid packages fast — invitation, scope, bid form, insurance, and schedule."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Barlow:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BinderHydrate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$3 = () => import("./routes-CQNE1MOd.mjs");
var Route$3 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./settings-BbvttvYw.mjs");
var Route$2 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./package._id-vIdb3-mN.mjs");
var Route$1 = createFileRoute("/package/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./print._id-BJt_gusR.mjs");
var Route = createFileRoute("/print/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	SettingsRoute: Route$2.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$4
	}),
	PackageIdRoute: Route$1.update({
		id: "/package/$id",
		path: "/package/$id",
		getParentRoute: () => Route$4
	}),
	PrintIdRoute: Route.update({
		id: "/print/$id",
		path: "/print/$id",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { newPackage as a, uid as c, useBinder as i, Route as n, cn as o, Route$1 as r, formatDate as s, router_exports as t };
