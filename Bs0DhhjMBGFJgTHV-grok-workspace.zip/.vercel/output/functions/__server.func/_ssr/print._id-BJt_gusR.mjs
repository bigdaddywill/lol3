import { _ as Link, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useBinder, n as Route } from "./router-Be4g4EZb.mjs";
import { t as Button } from "./button-BONEEdHX.mjs";
import { t as DocumentPreview } from "./document-preview-aXjmn4db.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/print._id-BJt_gusR.js
var import_jsx_runtime = require_jsx_runtime();
function PrintPage() {
	const { id } = Route.useParams();
	const pack = useBinder((s) => s.packages.find((p) => p.id === id));
	const company = useBinder((s) => s.company);
	if (!useBinder((s) => s.hydrated)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-8 text-sm",
		children: "Loading…"
	});
	if (!pack) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Package not found." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-3",
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Home"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg print:bg-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print flex items-center justify-between border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/package/$id",
					params: { id },
					children: "Back to editor"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => window.print(),
				children: "Print / save PDF"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl py-6 print:max-w-none print:py-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentPreview, {
				pack,
				company
			})
		})]
	});
}
//#endregion
export { PrintPage as component };
