//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DFD7LnZ4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/settings",
			"/package/$id",
			"/print/$id"
		],
		preloads: [
			"/assets/index-B8mGIXRd.js",
			"/assets/store-DM4sXblP.js",
			"/assets/preload-helper-y59AXtiw.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B8mGIXRd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BhyFr2dJ.js",
			"/assets/useNavigate-E6ouoeXl.js",
			"/assets/completeness-Dp0tpDzV.js",
			"/assets/button-BJJHbAV3.js",
			"/assets/input-sL3CYvtL.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-C0ilKerg.js",
			"/assets/arrow-left-YflxOp-J.js",
			"/assets/button-BJJHbAV3.js",
			"/assets/input-sL3CYvtL.js"
		]
	},
	"/package/$id": {
		filePath: "/workspace/src/routes/package.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/package._id-DqMwbioK.js",
			"/assets/useNavigate-E6ouoeXl.js",
			"/assets/arrow-left-YflxOp-J.js",
			"/assets/completeness-Dp0tpDzV.js",
			"/assets/button-BJJHbAV3.js",
			"/assets/input-sL3CYvtL.js",
			"/assets/document-preview-yr7g-n4l.js"
		]
	},
	"/print/$id": {
		filePath: "/workspace/src/routes/print.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/print._id-cOvqzbG9.js",
			"/assets/button-BJJHbAV3.js",
			"/assets/document-preview-yr7g-n4l.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
