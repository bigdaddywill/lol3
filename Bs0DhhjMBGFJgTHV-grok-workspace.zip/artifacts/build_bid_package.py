#!/usr/bin/env python3
"""Fictional sample bid package for training — not a real project."""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.colors import Color, HexColor, white, black
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

pdfmetrics.registerFont(TTFont("Lib", "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"))
pdfmetrics.registerFont(TTFont("LibB", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("LibI", "/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf"))
pdfmetrics.registerFont(TTFont("LibBI", "/usr/share/fonts/truetype/liberation/LiberationSans-BoldItalic.ttf"))

NAVY = HexColor("#1B2A4A")
STEEL = HexColor("#2F4A6D")
ACCENT = HexColor("#C45C26")
RULE = HexColor("#C9D0D8")
PALE = HexColor("#F4F6F8")
MUTED = HexColor("#5B6775")
GREEN = HexColor("#2E5E3F")
WARN = HexColor("#8A3B12")

OUT = "/home/workdir/artifacts/Sample_Bid_Package_TRAINING_ONLY.pdf"
W, H = letter
LM, RM = 0.7 * inch, 0.7 * inch
CONTENT_W = W - LM - RM


def wrap(c, text, font, size, max_w):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if c.stringWidth(trial, font, size) <= max_w:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


def header(c, page, total, title):
    c.setFillColor(NAVY)
    c.rect(0, H - 0.58 * inch, W, 0.58 * inch, fill=1, stroke=0)
    c.setFillColor(ACCENT)
    c.rect(0, H - 0.64 * inch, W, 0.06 * inch, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("LibB", 9)
    c.drawString(LM, H - 0.28 * inch, "REDROCK FIELD SERVICES")
    c.setFont("Lib", 8)
    c.drawRightString(W - RM, H - 0.22 * inch, "SUBCONTRACTOR BID PACKAGE")
    c.drawRightString(W - RM, H - 0.36 * inch, "Project RFS-26-441")
    c.setFillColor(MUTED)
    c.setFont("Lib", 7.5)
    c.drawString(LM, H - 0.82 * inch, title)
    c.drawRightString(W - RM, H - 0.82 * inch, f"Page {page} of {total}")
    c.setStrokeColor(RULE)
    c.setLineWidth(0.4)
    c.line(LM, H - 0.90 * inch, W - RM, H - 0.90 * inch)


def footer(c):
    c.setFillColor(PALE)
    c.rect(0, 0, W, 0.42 * inch, fill=1, stroke=0)
    c.setFillColor(WARN)
    c.setFont("LibB", 7)
    c.drawCentredString(W / 2, 0.24 * inch, "FICTIONAL TRAINING SAMPLE  •  NOT A REAL BID  •  DO NOT SUBMIT")
    c.setFillColor(MUTED)
    c.setFont("Lib", 6.5)
    c.drawCentredString(W / 2, 0.12 * inch, "Names, store numbers, limits, and quantities are invented for contractor training only.")


def watermark(c):
    c.saveState()
    c.setFillColor(Color(0.75, 0.18, 0.08, alpha=0.08))
    c.setFont("LibB", 52)
    c.translate(W / 2, H / 2)
    c.rotate(32)
    c.drawCentredString(0, 0, "SAMPLE / TRAINING")
    c.restoreState()


def section(c, y, label):
    c.setFillColor(STEEL)
    c.roundRect(LM, y - 4, CONTENT_W, 16, 2, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("LibB", 8.5)
    c.drawString(LM + 8, y, label)
    return y - 22


def kv(c, y, key, val, key_w=1.7 * inch):
    c.setFont("LibB", 8)
    c.setFillColor(NAVY)
    c.drawString(LM, y, key)
    c.setFont("Lib", 8)
    c.setFillColor(black)
    lines = wrap(c, val, "Lib", 8, CONTENT_W - key_w)
    c.drawString(LM + key_w, y, lines[0])
    for i, line in enumerate(lines[1:], 1):
        c.drawString(LM + key_w, y - i * 11, line)
    return y - 11 * max(1, len(lines)) - 4


def bullets(c, y, items, size=8.2, leading=12.2):
    c.setFont("Lib", size)
    c.setFillColor(black)
    for item in items:
        lines = wrap(c, item, "Lib", size, CONTENT_W - 14)
        c.setFillColor(ACCENT)
        c.circle(LM + 4, y + 2, 1.6, fill=1, stroke=0)
        c.setFillColor(black)
        for i, line in enumerate(lines):
            c.drawString(LM + 12, y, line)
            y -= leading
    return y


def table(c, y, headers, rows, col_ws, header_fill=NAVY):
    row_h = 16
    x = LM
    c.setFillColor(header_fill)
    c.rect(LM, y - row_h + 4, CONTENT_W, row_h, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("LibB", 7.2)
    xx = LM
    for h, w in zip(headers, col_ws):
        c.drawString(xx + 5, y - 7, h)
        xx += w
    y -= row_h
    c.setFont("Lib", 7.4)
    for i, row in enumerate(rows):
        if i % 2 == 0:
            c.setFillColor(PALE)
            c.rect(LM, y - row_h + 4, CONTENT_W, row_h, fill=1, stroke=0)
        c.setStrokeColor(RULE)
        c.setLineWidth(0.3)
        c.line(LM, y - row_h + 4, LM + CONTENT_W, y - row_h + 4)
        xx = LM
        for j, (cell, w) in enumerate(zip(row, col_ws)):
            c.setFillColor(black)
            c.drawString(xx + 5, y - 7, str(cell))
            xx += w
        y -= row_h
    return y - 6


def page1(c):
    header(c, 1, 7, "01  —  Invitation to Bid")
    watermark(c)
    footer(c)

    y = H - 1.15 * inch
    c.setFillColor(NAVY)
    c.setFont("LibB", 16)
    c.drawString(LM, y, "Invitation to Bid")
    y -= 16
    c.setFont("Lib", 9)
    c.setFillColor(MUTED)
    c.drawString(LM, y, "Trade: Cast-in-Place Concrete Repair  •  Bid Package No. 03A")
    y -= 18

    c.setFillColor(PALE)
    c.roundRect(LM, y - 92, CONTENT_W, 96, 4, fill=1, stroke=0)
    c.setFillColor(ACCENT)
    c.rect(LM, y - 92, 5, 96, fill=1, stroke=0)
    y -= 14
    y = kv(c, y, "Project", "Atlas Fresh #1847 — Receiving Dock & Apron Repairs")
    y = kv(c, y, "Address", "8821 W Pioneer Rd, West Jordan, UT 84088")
    y = kv(c, y, "Owner", "Atlas Fresh Markets, Inc.  ( Occupied store )")
    y = kv(c, y, "General Contractor", "Redrock Field Services, LLC  •  Salt Lake City, UT")
    y = kv(c, y, "GC Project No.", "RFS-26-441")
    y -= 10

    y = section(c, y, "BID MILESTONES")
    y = table(
        c, y,
        ["Item", "Date / Time", "Notes"],
        [
            ["Documents issued", "Thu, Sep 17, 2026", "This package + drawing link"],
            ["RFIs due", "Mon, Sep 28, 2026  12:00 PM MT", "Email only — see contacts"],
            ["Bids due", "Thu, Oct 2, 2026  2:00 PM MT", "Late bids not opened"],
            ["Apparent low notified", "Fri, Oct 3, 2026", "Subject to vetting"],
            ["Night work window", "Oct 19 – Nov 8, 2026", "10:00 PM – 5:00 AM"],
        ],
        [2.1 * inch, 2.3 * inch, CONTENT_W - 4.4 * inch],
    )

    y = section(c, y, "HOW TO SUBMIT")
    y = bullets(c, y, [
        "Email one PDF to bids@redrockfield.example with subject: RFS-26-441 / 03A / [Your Company].",
        "Include: signed bid form, Utah contractor license, current COI, and bondability letter if your total exceeds $75,000.",
        "Unit prices on the bid form are mandatory. A lump-sum-only quote will be marked incomplete.",
        "Do not text numbers to the superintendent. Text is for scheduling only.",
    ])
    y -= 6
    y = section(c, y, "WHAT THIS IS / WHAT THIS IS NOT")
    y = bullets(c, y, [
        "This is a bid invitation from a general contractor to pre-screened and open-trade concrete subcontractors.",
        "This is not a store-manager handshake, a verbal award, or a request for a deposit.",
        "Award, if any, will be a written subcontract on Redrock’s short form after insurance is approved.",
    ])


def page2(c):
    header(c, 2, 7, "02  —  Project Data & Contacts")
    watermark(c)
    footer(c)
    y = H - 1.15 * inch

    y = section(c, y, "PROJECT DATA")
    y = table(
        c, y,
        ["Field", "Value"],
        [
            ["Store / site ID", "Atlas Fresh #1847"],
            ["Building status", "Occupied grocery — receiving dock remains live"],
            ["Approx. work area", "11,800 SF apron + 420 LF joints + 7 column bases"],
            ["Concrete age / type", "Existing 6\" unreinforced / lightly reinforced dock slab, ~2009"],
            ["Access", "West receiving yard only. No customer parking lot staging."],
            ["Dumpster / washout", "GC provides one 30-yd and a lined washout. Sub loads it."],
            ["Permits", "GC holds building permit. Sub pulls any night-work noise permit if City requires."],
            ["Prevailing wage", "No. Private owner."],
            ["Tax", "Utah sales tax extra / shown separately on bid form."],
        ],
        [2.2 * inch, CONTENT_W - 2.2 * inch],
    )

    y -= 4
    y = section(c, y, "CONTACTS  —  USE THESE, NOT A PERSONAL CELL AS THE ONLY RECORD")
    y = table(
        c, y,
        ["Role", "Name", "Email / phone"],
        [
            ["Project manager", "Dana Ruiz", "druiz@redrockfield.example  •  801-555-0144"],
            ["Superintendent", "Cole Maddox", "cmaddox@redrockfield.example  •  801-555-0192"],
            ["Estimator / bids", "Bids desk", "bids@redrockfield.example"],
            ["Owner facilities", "Atlas Fresh — Store Planning", "facilities@atlasfresh.example"],
            ["Store manager", "On-site after award only", "Do not solicit the store before award"],
        ],
        [1.7 * inch, 1.9 * inch, CONTENT_W - 3.6 * inch],
    )

    y -= 2
    y = section(c, y, "DOCUMENTS IN THIS PACKAGE")
    y = bullets(c, y, [
        "01 Invitation to Bid",
        "02 Project Data & Contacts",
        "03 Scope of Work — Bid Package 03A",
        "04 Bid Form (required)",
        "05 Insurance, Bond & Safety Minimums",
        "06 Work Restrictions — Occupied Store / Night Shift",
        "07 Sketch Plan SK-1 (not for construction; issued for bidding only)",
        "Not included in this training sample: full civil CAD, spec book Section 03 01 30, and geotech note. On a real job those come as a file link.",
    ])
    y -= 8
    c.setFillColor(HexColor("#EAF1E8"))
    c.roundRect(LM, y - 70, CONTENT_W, 74, 4, fill=1, stroke=0)
    c.setFillColor(GREEN)
    c.setFont("LibB", 8)
    c.drawString(LM + 10, y - 16, "REALITY CHECK FOR THE SUB")
    c.setFillColor(black)
    c.setFont("Lib", 8)
    for i, line in enumerate([
        "If the only thing you have is an iMessage and a first name, you do not have a bid package.",
        "A real package has a project number, a due date, a written scope, and a GC email domain.",
        "Ask for this packet before you drive to the dock or give a number.",
    ]):
        c.drawString(LM + 10, y - 32 - i * 12, line)


def page3(c):
    header(c, 3, 7, "03  —  Scope of Work")
    watermark(c)
    footer(c)
    y = H - 1.15 * inch
    y = section(c, y, "BASE BID — PACKAGE 03A  CONCRETE REPAIR")
    y = bullets(c, y, [
        "Mobilize for night work at an occupied grocery receiving dock. Furnish labor, equipment, materials, haul-off, and protection.",
        "Sawcut, remove, and replace failed apron panels at Docks 3–6 as hatched on SK-1. Design thickness 7\" with #4 bars each way at 16\" O.C. Match existing dock height ±1/8\".",
        "Route and clean existing control/construction joints, 420 LF, and install two-component polyurea joint filler, Shore A 80–90, recessed 1/8\" from finished surface.",
        "Repair seven (7) spalled steel-column bases: chip to sound concrete, clean steel, apply approved bonding slurry, form and place polymer-modified repair mortar to original profile.",
        "Re-pitch a 12' x 18' low area at Dock 5 drain. Verify drain invert with superintendent before pour.",
        "Protect dock levelers, overhead doors, seals, and store wall. No dust inside the building. Negative-pressure or sealed openings required when chipping within 10' of an open door.",
        "Place, finish, cure, and saw new joints to match existing pattern. Curing compound compatible with joint filler.",
        "Daily cleanup. Leave two dock positions usable each morning by 5:00 AM unless a written shutdown is issued the day prior.",
    ])
    y -= 4
    y = section(c, y, "INCLUDED")
    y = bullets(c, y, [
        "Night-shift premium, lights, and a spotter when trucks are backing.",
        "Traffic cones / 28\" cones and 3 lighted barricades at the work face.",
        "All concrete, rebar, dowels, epoxy gel for dowels, joint filler, repair mortar, and bond breaker.",
        "Testing: GC will pay for 1 set of cylinders per pour night. Retests caused by low breaks are the sub’s cost.",
    ])
    y -= 4
    y = section(c, y, "EXCLUDED  (do not hide these in a verbal quote)")
    y = bullets(c, y, [
        "Dock leveler replacement or pit steel.",
        "Overhead doors, seals, bumpers, or striping.",
        "Underground plumbing beyond the one drain re-pitch shown.",
        "Hazardous material abatement. If you hit something that is not concrete, stop and call the superintendent.",
        "Winter chemicals beyond mix design already specified. If a pour night drops below 35°F, GC issues a written change.",
    ])
    y -= 4
    y = section(c, y, "UNIT PRICES  —  WILL BE USED FOR ADDS / DEDUCTS")
    y = bullets(c, y, [
        "Extra / credit panel replacement per SF.",
        "Extra / credit joint filler per LF.",
        "Extra column-base repair each.",
        "Standby hourly rate if the store holds a dock after 10:30 PM through no fault of the sub.",
    ])


def page4(c):
    header(c, 4, 7, "04  —  Bid Form (required)")
    watermark(c)
    footer(c)
    y = H - 1.15 * inch
    c.setFont("LibB", 11)
    c.setFillColor(NAVY)
    c.drawString(LM, y, "Bid Form — Package 03A")
    y -= 14
    c.setFont("Lib", 8)
    c.setFillColor(MUTED)
    c.drawString(LM, y, "Complete every line. Incomplete forms are not evaluated.")
    y -= 16

    # company block
    fields = [
        ("Subcontractor legal name", "________________________________"),
        ("Utah license no. / classification", "________________________________"),
        ("Contact / cell / email", "________________________________"),
        ("Bid date", "________________________________"),
    ]
    for lab, line in fields:
        c.setFont("LibB", 8)
        c.setFillColor(NAVY)
        c.drawString(LM, y, lab)
        c.setFont("Lib", 8)
        c.setFillColor(black)
        c.drawString(LM + 2.4 * inch, y, line)
        y -= 16

    y -= 4
    y = section(c, y, "PRICE BREAKOUT  (USD)")
    y = table(
        c, y,
        ["Item", "Qty", "Unit", "Unit price", "Amount"],
        [
            ["Mobilization / night setup / protection", "1", "LS", "$ ________", "$ ________"],
            ["Apron panel remove & replace", "4,250", "SF", "$ ________", "$ ________"],
            ["Joint route / clean / polyurea fill", "420", "LF", "$ ________", "$ ________"],
            ["Column-base spall repairs", "7", "EA", "$ ________", "$ ________"],
            ["Dock 5 drain re-pitch", "1", "LS", "$ ________", "$ ________"],
            ["Haul-off / dump fees beyond GC box", "1", "LS", "$ ________", "$ ________"],
            ["BASE BID  (sum of lines above)", "", "", "", "$ ________"],
            ["Utah sales tax  (if applicable)", "", "", "", "$ ________"],
            ["TOTAL BID", "", "", "", "$ ________"],
        ],
        [2.55 * inch, 0.7 * inch, 0.55 * inch, 1.15 * inch, CONTENT_W - 4.95 * inch],
    )

    y -= 2
    y = section(c, y, "UNIT PRICES FOR CHANGES")
    y = table(
        c, y,
        ["Description", "Unit", "Add", "Deduct"],
        [
            ["Additional panel replacement", "SF", "$ ________", "$ ________"],
            ["Additional joint filler", "LF", "$ ________", "$ ________"],
            ["Additional column-base repair", "EA", "$ ________", "$ ________"],
            ["Crew standby after 10:30 PM, store delay", "HR", "$ ________", "n/a"],
        ],
        [3.2 * inch, 0.7 * inch, 1.3 * inch, CONTENT_W - 5.2 * inch],
    )

    y -= 2
    y = section(c, y, "ACKNOWLEDGEMENTS  —  INITIAL")
    y = bullets(c, y, [
        "____  I received Invitation, Scope, Bid Form, Insurance sheet, Work Restrictions, and SK-1.",
        "____  I can staff nights 10:00 PM – 5:00 AM on the dates in this package.",
        "____  I can furnish the insurance limits on page 5 within 5 days of notice of award.",
        "____  If my bid is over $75,000 I attach a surety letter of bondability.",
        "____  This bid is firm for 30 days. No deposit, materials prepay, or off-contract payment is requested.",
    ])
    y -= 10
    c.setFont("LibB", 8)
    c.setFillColor(NAVY)
    c.drawString(LM, y, "Authorized signature: _______________________________    Date: ______________")
    y -= 14
    c.setFont("Lib", 8)
    c.drawString(LM, y, "Printed name / title: _______________________________________________")


def page5(c):
    header(c, 5, 7, "05  —  Insurance, Bond & Safety")
    watermark(c)
    footer(c)
    y = H - 1.15 * inch
    y = section(c, y, "CERTIFICATE OF INSURANCE  —  MINIMUMS")
    y = table(
        c, y,
        ["Coverage", "Minimum limit", "Notes"],
        [
            ["Commercial General Liability", "$1,000,000 occ / $2,000,000 agg", "Per project aggregate"],
            ["Auto liability", "$1,000,000", "Any auto"],
            ["Workers’ compensation", "Statutory", "Include waiver of subrogation"],
            ["Employer’s liability", "$1,000,000", ""],
            ["Umbrella / excess", "$1,000,000", "Required if base bid ≥ $75,000"],
        ],
        [2.2 * inch, 2.2 * inch, CONTENT_W - 4.4 * inch],
    )
    y = bullets(c, y, [
        "Additional insureds, on a primary and non-contributory basis: Redrock Field Services, LLC and Atlas Fresh Markets, Inc.",
        "Waiver of subrogation in favor of the same parties on GL, auto, and workers’ comp.",
        "Certificate holder address: Redrock Field Services, 410 W 300 S, Ste 220, Salt Lake City, UT 84101.",
        "Do not send a homeowner policy, a personal auto card, or a screenshot of an app.",
    ])
    y -= 6
    y = section(c, y, "BOND")
    y = bullets(c, y, [
        "Bids of $75,000 and over: attach a letter from a surety admitted in Utah stating you can bond the subcontract.",
        "If awarded over $75,000, a performance and payment bond equal to 100% of the subcontract may be required within 10 days.",
        "Bond premium, if required, is a line-item reimbursable at cost with backup. Do not hide it and do not invent it.",
        "“Bonded” does not mean licensed, insured, or BBB accredited. It means a surety will stand behind the job.",
    ])
    y -= 6
    y = section(c, y, "SAFETY / SITE RULES THAT AFFECT PRICE")
    y = bullets(c, y, [
        "Hard hats, hi-vis, eye protection after dark. No earbuds in the yard.",
        "Sawcutting: wet cut only. Slurry contained. No slurry in the drain.",
        "ISNetworld is not required on this training sample. On some national retailers it is required before you can even get the drawings.",
        "Your EMR and a 1-page safety sheet may be requested before award. Have them ready.",
        "Any injury, property strike, or store complaint is reported to the superintendent before the shift ends.",
    ])
    y -= 8
    c.setFillColor(HexColor("#F8EDE6"))
    c.roundRect(LM, y - 58, CONTENT_W, 62, 4, fill=1, stroke=0)
    c.setFillColor(WARN)
    c.setFont("LibB", 8)
    c.drawString(LM + 10, y - 16, "COMMON SCAM TELL")
    c.setFillColor(black)
    c.setFont("Lib", 8)
    c.drawString(LM + 10, y - 32, "A real GC asks for a COI and maybe a bond letter. A fake GC asks you to pay a vendor,")
    c.drawString(LM + 10, y - 44, "buy materials from their “supplier,” or cash an overpayment check. Walk away.")


def page6(c):
    header(c, 6, 7, "06  —  Occupied Store / Night Work Restrictions")
    watermark(c)
    footer(c)
    y = H - 1.15 * inch
    y = section(c, y, "HOURS")
    y = bullets(c, y, [
        "Work face opens 10:00 PM. Tools down, yard swept, docks released by 5:00 AM.",
        "No arrival staging in customer parking before 9:30 PM.",
        "Sunday nights available only with 72-hour written approval from the store.",
    ])
    y -= 4
    y = section(c, y, "STORE OPERATIONS")
    y = bullets(c, y, [
        "Docks 1 and 2 stay live every night unless a shutdown ticket is issued that afternoon.",
        "Trucks will still back into the yard. One spotter from the sub crew is required whenever a mixer or saw is in the drive lane.",
        "No radios pointed at the building. No music. No idling under the canopy after 10:30 PM.",
        "Dust, slurry, and noise complaints from the store manager are treated as a failed shift. Second failed shift can get you walked.",
    ])
    y -= 4
    y = section(c, y, "PHASING  (BID THIS SEQUENCE)")
    y = table(
        c, y,
        ["Phase", "Nights (est.)", "Work"],
        [
            ["A", "2", "Joints at Docks 1–2  (live docks — small tools only)"],
            ["B", "4", "Remove/replace apron panels Docks 3–4"],
            ["C", "4", "Remove/replace apron panels Docks 5–6 + drain re-pitch"],
            ["D", "2", "Column bases + punch / joint filler at new saw cuts"],
        ],
        [0.8 * inch, 1.4 * inch, CONTENT_W - 2.2 * inch],
    )
    y -= 4
    y = section(c, y, "WHAT YOU MAY ASK THE GC BEFORE YOU BID")
    y = bullets(c, y, [
        "May I see the store after 9:00 PM if I check in with the night manager?  (Yes, after you are on the bidder list.)",
        "Is there a geotech or as-built showing slab thickness at the hatch?  (GC should answer or issue an addendum.)",
        "Who owns the dumpster overages?  (Answered in this package: sub loads, GC box, overages on the bid form.)",
        "What is the liquidated-damage number if a dock is not released at 5:00 AM?  (On this sample: $500 per dock per hour, capped at $2,500/night.)",
    ])
    y -= 6
    c.setFillColor(PALE)
    c.roundRect(LM, y - 80, CONTENT_W, 84, 4, fill=1, stroke=0)
    c.setFillColor(NAVY)
    c.setFont("LibB", 8)
    c.drawString(LM + 10, y - 16, "HOW THIS BEATS A COLD TEXT")
    c.setFont("Lib", 8)
    c.setFillColor(black)
    for i, line in enumerate([
        "You now have: a company, a project number, an address, a due date, quantities,",
        "a place to send the bid, insurance limits, and work hours in writing.",
        "That is the packet you ask for when someone texts “I found your LLC.”",
        "If they cannot produce a version of pages 1–6, there is nothing to bid.",
    ]):
        c.drawString(LM + 10, y - 32 - i * 12, line)


def page7(c):
    header(c, 7, 7, "07  —  Sketch Plan SK-1  (bidding only)")
    watermark(c)
    footer(c)

    y = H - 1.12 * inch
    c.setFont("LibB", 10)
    c.setFillColor(NAVY)
    c.drawString(LM, y, "SK-1  Receiving Yard — Atlas Fresh #1847")
    c.setFont("LibI", 8)
    c.setFillColor(MUTED)
    c.drawRightString(W - RM, y, "Not for construction")

    # drawing frame
    fx, fy, fw, fh = LM, 1.55 * inch, CONTENT_W, 6.55 * inch
    c.setStrokeColor(NAVY)
    c.setLineWidth(1.2)
    c.rect(fx, fy, fw, fh, fill=0, stroke=1)
    c.setFillColor(HexColor("#EEF2F5"))
    c.rect(fx + 1, fy + 1, fw - 2, fh - 2, fill=1, stroke=0)

    # building
    bx, by, bw, bh = fx + 0.35 * inch, fy + 3.55 * inch, fw - 0.7 * inch, 2.55 * inch
    c.setFillColor(HexColor("#D9E0E8"))
    c.setStrokeColor(NAVY)
    c.setLineWidth(1)
    c.rect(bx, by, bw, bh, fill=1, stroke=1)
    c.setFillColor(NAVY)
    c.setFont("LibB", 9)
    c.drawCentredString(bx + bw / 2, by + bh / 2 + 6, "ATLAS FRESH  #1847")
    c.setFont("Lib", 8)
    c.drawCentredString(bx + bw / 2, by + bh / 2 - 8, "SALES FLOOR  (DO NOT ENTER)")

    # docks
    dock_w = 0.85 * inch
    gap = 0.18 * inch
    start_x = bx + 0.55 * inch
    docks = [
        ("1", False, "LIVE"),
        ("2", False, "LIVE"),
        ("3", True, "R&R"),
        ("4", True, "R&R"),
        ("5", True, "R&R+DRAIN"),
        ("6", True, "R&R"),
    ]
    for i, (num, work, tag) in enumerate(docks):
        dx = start_x + i * (dock_w + gap)
        dy = by - 0.55 * inch
        color = HexColor("#E8B89A") if work else HexColor("#C5D5C8")
        c.setFillColor(color)
        c.setStrokeColor(NAVY)
        c.rect(dx, dy, dock_w, 0.55 * inch, fill=1, stroke=1)
        c.setFillColor(NAVY)
        c.setFont("LibB", 8)
        c.drawCentredString(dx + dock_w / 2, dy + 0.30 * inch, f"DOCK {num}")
        c.setFont("Lib", 6.5)
        c.drawCentredString(dx + dock_w / 2, dy + 0.12 * inch, tag)

    # apron
    ax, ay, aw, ah = bx, fy + 1.15 * inch, bw, 1.85 * inch
    c.setFillColor(HexColor("#CFD6DD"))
    c.setStrokeColor(STEEL)
    c.setDash(3, 2)
    c.rect(ax, ay, aw, ah, fill=1, stroke=1)
    c.setDash()
    c.setFillColor(NAVY)
    c.setFont("LibB", 8)
    c.drawString(ax + 8, ay + ah - 14, "CONCRETE APRON  ~11,800 SF")
    c.setFont("Lib", 7)
    c.drawString(ax + 8, ay + ah - 26, "Hatched panels at Docks 3–6 = remove & replace  (4,250 SF)")

    # hatch marks over docks 3-6 apron
    hx = start_x + 2 * (dock_w + gap)
    hw = 4 * dock_w + 3 * gap
    c.setStrokeColor(ACCENT)
    c.setLineWidth(0.6)
    x0 = hx
    while x0 < hx + hw:
        c.line(x0, ay + 8, x0 + 14, ay + ah - 36)
        x0 += 10

    # column bases
    c.setFillColor(ACCENT)
    cols_x = [ax + 0.7 * inch + i * 0.95 * inch for i in range(7)]
    for i, cx in enumerate(cols_x):
        c.circle(cx, by + 0.18 * inch, 5, fill=1, stroke=0)
        c.setFillColor(NAVY)
        c.setFont("Lib", 5.5)
        c.drawCentredString(cx, by + 0.32 * inch, f"CB{i+1}")
        c.setFillColor(ACCENT)

    # drain
    drain_x = start_x + 4 * (dock_w + gap) + dock_w / 2
    c.setStrokeColor(HexColor("#1A5F8A"))
    c.setLineWidth(1.2)
    c.circle(drain_x, ay + 0.55 * inch, 8, fill=0, stroke=1)
    c.line(drain_x - 5, ay + 0.55 * inch, drain_x + 5, ay + 0.55 * inch)
    c.line(drain_x, ay + 0.55 * inch - 5, drain_x, ay + 0.55 * inch + 5)
    c.setFillColor(HexColor("#1A5F8A"))
    c.setFont("LibB", 6.5)
    c.drawCentredString(drain_x, ay + 0.28 * inch, "DRAIN / RE-PITCH")

    # north arrow
    nx, ny = fx + fw - 0.55 * inch, fy + fh - 0.7 * inch
    c.setFillColor(NAVY)
    path = c.beginPath()
    path.moveTo(nx, ny + 18)
    path.lineTo(nx - 7, ny - 4)
    path.lineTo(nx, ny + 2)
    path.lineTo(nx + 7, ny - 4)
    path.close()
    c.drawPath(path, fill=1, stroke=0)
    c.setFont("LibB", 7)
    c.drawCentredString(nx, ny - 16, "N")

    # legend
    c.setFillColor(white)
    c.setStrokeColor(NAVY)
    c.setLineWidth(0.6)
    c.rect(fx + 8, fy + 8, 3.35 * inch, 0.95 * inch, fill=1, stroke=1)
    c.setFont("LibB", 7)
    c.setFillColor(NAVY)
    c.drawString(fx + 14, fy + 0.82 * inch, "LEGEND")
    c.setFillColor(HexColor("#C5D5C8"))
    c.rect(fx + 14, fy + 0.58 * inch, 10, 8, fill=1, stroke=1)
    c.setFillColor(black)
    c.setFont("Lib", 6.5)
    c.drawString(fx + 28, fy + 0.59 * inch, "Live dock — protect only")
    c.setFillColor(HexColor("#E8B89A"))
    c.rect(fx + 14, fy + 0.40 * inch, 10, 8, fill=1, stroke=1)
    c.setFillColor(black)
    c.drawString(fx + 28, fy + 0.41 * inch, "Remove & replace apron panel")
    c.setFillColor(ACCENT)
    c.circle(fx + 19, fy + 0.26 * inch, 4, fill=1, stroke=0)
    c.setFillColor(black)
    c.drawString(fx + 28, fy + 0.23 * inch, "Spalled column base (7 total)")

    c.setFillColor(MUTED)
    c.setFont("LibI", 7)
    c.drawString(LM, 1.22 * inch, "Joints: existing grid, 420 LF to route and fill — see spec 03 01 30 (not attached in this sample).")
    c.drawString(LM, 1.08 * inch, "Scale: diagrammatic. Field-measure all quantities. Discrepancies over 10% are an RFI, not a guess.")


def main():
    c = canvas.Canvas(OUT, pagesize=letter)
    c.setTitle("Sample Bid Package RFS-26-441 — TRAINING ONLY")
    c.setAuthor("Redrock Field Services (fictional)")
    pages = [page1, page2, page3, page4, page5, page6, page7]
    for fn in pages:
        fn(c)
        c.showPage()
    c.save()
    print(OUT)


if __name__ == "__main__":
    main()
